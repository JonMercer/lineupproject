Status Monitor API Manual
  for "TM/BA Series Printer Driver for Linux"

Contents
1. License agreement
2. Explanation of this product
3. Install
4. Uninstall
5. Notes/Restrictions
6. Modification from the old version


------------------------------------------------------------------------
1. License agreement
------------------------------------------------------------------------

This package is distributed on the basis of a non-free proprietary license.
Please refer to the attached EULA.TXT for details.


------------------------------------------------------------------------
2. Explanation of this product
------------------------------------------------------------------------

This software is a status monitor API for "TM/BA Series Printer Driver 
for Linux." Advanced functions for monitoring printers can be embedded 
in applications with print functions.

2.1. Supported models

This software supports all models supported by "TM/BA Series Printer 
Driver for Linux."
For details, please refer to the driver manual of "TM/BA Series Printer 
Driver for Linux."


2.2. Supported interface

For the supported interfaces, they are equal to "TM/BA Series Printer 
Driver for Linux."
This software uses specific port communication module PCS (EPSON Port
Communication Service) as well as "TM/BA Series Printer Driver for 
Linux."


2.3. System Requirements

This software supports the following system environment.
It does not warrant operation on other than supported system environment.

* Operating System
  - openSUSE 11.1
  - openSUSE 12.2
  - Ubuntu 9.04
  - Ubuntu 12.04

* Hardware:
  - Intel x86(32bit) architecture.
  - Intel x64(64bit) architecture.


2.4. Software requirements for operation

Software requirements of this software are as follows:
Please install the following software before installing this software.

* CUPS Ver.1.2 or later
      <http://www.cups.org/>

* Port communication module PCS(EPSON Port Communication Service)
  Ver.3.8.0 or later

* TM/BA Series Printer Driver for Linux Ver.2.0.0.0 or later


2.5. Contents of the package

    non-free proprietary license modules:
        32-bit:
            /usr/lib/libEpsStmApi.so
            /usr/lib/libEpsStmPosData.so

        64-bit:
            /usr/lib64/libEpsStmApi.so
            /usr/lib64/libEpsStmPosData.so

    Documents:
        README.ja.txt (Japanese)
        README.en.txt (English)

    License files:
        EULA.ja.txt (Japanese)
        EULA.en.txt (English)


------------------------------------------------------------------------
3. Install
------------------------------------------------------------------------

Installation procedure of this software is as follows:

  * Run install-stmapi.sh.

    Run install-stmapi.sh by either clicking the install.sh icon. Or,
    enter to the directory where the installation package has been expanded,
    then run install.sh by typing the following in the command line prompt.
    # ./install-stmapi.sh

  Note)
    ! You need root privileges for the installation.
      If you do not have root privileges, install-stmapi.sh will execute
      the sudo command. Type the password.
    ! Switch the printer off before installing the driver.

  * If you have a previous version installed, you must uninstall 
    the previous version first. When previous version found, 
    detailed information and the message asking if you wish to uninstall 
    will be shown.
    If no problem, enter "y" and press the Enter key.

    Message example) 
    Incompatible version of TM/BA series printer status monitor API found!
    Before the installation, package:"epson-stmapi" must be uninstalled.
      Packages to be uninstalled:
        epson-stmapi-1.0.0-4
    
    Uninstall the incompatible status monitor API: epson-stmapi  [y/n]? y
    ...(Omitted)

  * After determining the environment, information about the package to be 
    installed and the distribution will be displayed. 
    If the information is correct, enter "y" and press the Enter key.

    Example) Message for openSUSE 11.1 x86(32bit) architecture
    Install tmx-stmapi-2.0.0-1 into openSUSE 11.1 x86(32bit) [y/n]? 

  * If the displayed distribution is not the one you are installing,
    enter "n" and press the Enter key. The distribution selection 
    screen is displayed. Enter a number between 1 and 8, and press 
    the Enter key.
    Enter "0" and press the Enter key to cancel the installation.

    Please select your distribution.
    1.Ubuntu 12.04 x86(32bit)
    2.Ubuntu 12.04 x86_64(64bit)
    3.Ubuntu 9.04 x86(32bit)
    4.Ubuntu 9.04 x86_64(64bit)
    5.openSUSE 11.1 x86(32bit)
    6.openSUSE 11.1 x86_64(64bit)
    7.openSUSE 12.2 x86(32bit)
    8.openSUSE 12.2 x86_64(64bit)
    Select number [0(cancel)/1/2/3/4/5/6/7/8]?

  * Installation will start as you select the distribution


------------------------------------------------------------------------
4. Uninstall
------------------------------------------------------------------------

The following describes how to uninstall this software.

  - Change directory where the installation package expanded,
    and execute uninstall-stmapi.sh shell script.
    # ./uninstall-stmapi.sh

  Note)
    ! You need root privilege to uninstall the software.


------------------------------------------------------------------------
5. Notes/Restrictions
------------------------------------------------------------------------

- Before using StatusAPI, register TM/BA Series Printer to CUPS.


---------------------------------------------------------------------
6. Modification from the old version
---------------------------------------------------------------------

* Ver. 2.0.0

  - The following printers are supported:
   [TM generic models]
    - TM BA Thermal Printer
    - TM Impact Receipt Printer
    - TM Slip Printer
   [Supported models with the TM general models]
    - TM-H6000II (Receipt, Slip)
    - TM-H6000III (Receipt, Slip)
    - TM-H6000IV (Receipt, Slip)
    - TM-T70
    - TM-T70 ANK
    - TM-T90
    - TM-T90 ANK
    - TM-T90II
    - TM-U120
    - TM-U120II
    - TM-U230
    - TM-U375 (Receipt, Slip)
    - TM-U675 (Receipt, Slip)
  - The driver package name changed. (epson-stmapi-* -> tmx-stmapi-*)
  - Comminication module has been changed to PCS(Port Comminication 
    Service).
  - Added openSUSE 12.2 support.
  - Added Ubuntu 12.04 support.
  - Installation and uninstallation scripts provided.


* Ver. 1.0.0

  - New release.


------------------------------------------------------------------------
Copyright (C) Seiko Epson Corporation 2010-2014. All rights reserved

Linux is the registered trademark of Linus Torvalds in the U.S. and other countries. 

CUPS and the CUPS logo are trademarks of Apple Inc. in the U.S. and other countries. 

"Novell" and "openSUSE" are trademarks of Novell, Inc., which founded, sponsors,
and is designated by, The openSUSE Project. 

Ubuntu and Canonical are registered trademarks of Canonical Ltd.

All other product name trademarks of their respective owners.
