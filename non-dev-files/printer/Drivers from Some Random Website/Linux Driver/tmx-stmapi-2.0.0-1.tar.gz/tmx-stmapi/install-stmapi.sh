#!/bin/bash

#set -x
LC_ALL=C
export LC_ALL

# Status monitor API name
stmapiname="TM/BA Series Printer Status Monitor API for Linux"
stmapiver="Ver.2.0.0"
package_name="tmx-stmapi-2.0.0-1"

# Interval (sec)
sleep_sec=0

## show version
##
version ()
{
	cat <<EOF
`basename $0`  for "${stmapiname}"  ${stmapiver}
  Copyright (C) 2014 Seiko Epson Corporation. All rights reserved.

EOF
}

## show incompatible packages to be uninstalled
##
show_incompatible ()
{
if test "" != "$uninstall_packages" ; then
cat <<EOF
Before the installation, package:"${incmptbl_package}" must be uninstalled.
  Packages to be uninstalled:
    $incmptbl_stmapi
EOF
cat <<EOF3

EOF3
fi
}

## show usage
##
usage ()
{
cat <<EOF
Package installer for "${stmapiname}"
  Target package: ${package_name}

usage: `basename $0` [option]

  option:
	-t | --test    Test mode          (do not install)
	-h | --help    Show help message  (do not install)
	-u | --usage   Show usage message (do not install)
	-v | --version Show version info  (do not install)

EOF
if test "$1" != "0" ; then
	show_incompatible
fi
}

## wait Enter key pressed
##
press_enter_key ()
{
	echo -n "Press the Enter key."
	read REPLY
}

## check command validity
##
check_command ()
{
    which "$1" 1>/dev/null 2>&1
}

#
# Prepare for installation
#
# check package management system.
default_packager=""
for cmd in rpm dpkg ; do
    check_command $cmd
    if test $? -eq 0 ; then
		default_packager=$cmd
    fi
done
if test -z ${default_packager} ; then
    echo "[ERROR] Fatal error."
    press_enter_key
    exit 255
fi

#
# Check installed package
#
# Uninstall target (incompatible version status monitor API packages)
target_packages="
    epson-stmapi
"
# Control variables to be set here:
#	uninstaller			uninstall command
#	uninstall_packages	packages to be uninstalled
#	incmptbl_package	incompatible version package name to be uninstalled
#	incmptbl_stmapi		incompatible version stmapi package to be uninstalled
uninstaller=""
uninstall_packages=""
incmptbl_package="(unknown)"
incmptbl_stmapi="(not found)"
for cmd in rpm dpkg ; do
    check_command $cmd
    if test $? -eq 0 ; then
		if test "rpm" = "$cmd" ; then
			option="-q"
		else
			option="-l"
		fi
		for package in ${target_packages} ; do
			if test "rpm" = "$cmd" ; then
				pkginfo=`$cmd ${option} ${package} 2>/dev/null`
			else
				pkginfo=`$cmd ${option} ${package} 2>/dev/null|grep ii`
			fi
			if test $? -eq 0 ; then
				uninstaller="$cmd"
				if test "rpm" = "$cmd" ; then
					# for rpm, pkginfo must be 'package-version' form
					pkg_ver="${pkginfo#$package?}"
				else
					# for dpkg, pkginfo must be 'ii package version description' form
					pkg_ver=`echo $pkginfo|cut -d " " -f 3`
				fi
				case "$package" in
					"epson-stmapi" )
						incmptbl_package="$package"
						incmptbl_stmapi="$package-$pkg_ver"
						uninstall_packages="$uninstall_packages
    $package"
						;;
					* ) ;;
				esac
			fi
		done
		test "" != "$uninstaller" && break
    fi
done
if test -z $uninstaller ; then
    uninstaller=${default_packager}
fi

#
# execute simple optional action, setting TEST option flag
#
TEST="no"
for a in $* ; do
	case "$a" in
		"-t" | "--test"    ) TEST="yes" ;;
		"-h" | "--help"    ) version ; usage ; exit 0 ;;
		"-u" | "--usage"   )           usage 0 ; exit 0 ;;
		"-v" | "--version" ) version ;         exit 0 ;;
		"--"               ) break ;;
		*) echo "[ERROR] Unknown option."; exit 255 ;;
	esac
done

# Change root.
if [ 0 -ne `id -u` ] ; then
	echo "Running the sudo command..."
	sudo "$0" $*
	status=$?
	if [ 1 -eq ${status} ] ; then
		echo ""
		echo "[ERROR] The sudo command failed."
		echo "[ERROR] Please execute the `basename $0` again after changing to the root."
		press_enter_key
	fi
	exit ${status}
fi

# show version at first.
version

#
# Uninstall incompatible TM/BA printer status monitor API installation, if detected
#
if test "" != "$uninstall_packages" ; then
	echo "Incompatible version of TM/BA printer status monitor API found!"
	show_incompatible

	# set uninstaller option.
	if test "rpm" = "${uninstaller}" ; then
		if test "no" = "${TEST}" ; then
		    option="-e"
		else
		    option="-e --test"
		fi
	else
		if test "no" = "${TEST}" ; then
		    option="-P"
		else
		    option="--no-act -P"
		fi
	fi

	if test "no" = "${TEST}" ; then
		# user confirm: uninstalling the incompatible printer status monitor API installation
		while true ; do
			echo -n "Uninstall the incompatible status monitor API: ${incmptbl_package}  [y/n]? "
			read a
			answer="`echo $a | tr A-Z a-z`"
			case "$answer" in
				"y" | "yes" ) break ;;
				"n" | "no"  )
					echo "Uninstallation canceled."
					echo ""
					echo "You can't install new TM/BA series printer status monitor API without uninstalling "
					echo "the incompatible version."
					press_enter_key
					exit 0 ;;
				* ) echo "[ERROR] Please enter \"y\" or \"n\"." ;;
			esac
		done

		# Do uninstall.
		for package in ${uninstall_packages} ; do
			echo "${uninstaller} ${option} ${package}"
			${uninstaller} ${option} ${package}
			sleep ${sleep_sec}
		done
		echo ""

	else
		# Do uninstall test.
		echo "* default_packager=${default_packager}"
		echo "* uninstaller=${uninstaller} ${option}"
		echo "* packages to be uninstalled: ${uninstall_packages}"
		echo "* Uninstall test:"
		${uninstaller} ${option} ${uninstall_packages}
		# force to yes on test mode.
		answer="y"
	fi
	echo ""
fi

#
# Start installation
#
# Set top directory.
programPath=`which $0`
topDir=`dirname "$programPath"`

## Subroutines
##

## Do distribution check. (return distName)
##
checkDistribution ()
{
	# check distribution
	checkdistName=`lsb_release -d 2>/dev/null`
	os=`echo "$checkdistName" | awk '{print $2}'`
	ver=`echo "$checkdistName" | awk '{print $3}'`
	p4=`echo "$checkdistName" | awk '{print $4}'`
	p5=`echo "$checkdistName" | awk '{print $5}'`
	if [ "xFedora" = x$os ]; then
		ver=$p4
	fi
	if [ "xUbuntu" = x$os ]; then
		if [ "12." = "${ver:0:3}" ]; then
			ver=${ver:0:5}
		fi
	fi
	if [ "SUSE-Linux-Enterprise-Desktop" = $os-$ver-$p4-$p5 ]; then
		os="SLED"
		ver=`echo "$checkdistName" | awk '{print $6}'`
	fi
	if [ "x" = x$os ]; then
		cat /etc/*release | grep -q openSUSE > /dev/null 2>&1
		if [ 0 -eq $? ]; then
			os="openSUSE"
			ver=`cat /etc/*release | head -1 | awk '{print $2}'`
		else
			cat /etc/*release | grep _ID= | grep -q Ubuntu > /dev/null 2>&1
			if [ 0 -eq $? ]; then
				os="Ubuntu"
				ver=`cat /etc/*release | grep DISTRIB_RELEASE=`
				ver=${ver#DISTRIB_RELEASE=}
			else
				cat /etc/*release | head -1 | grep -q Fedora > /dev/null 2>&1
				if [ 0 -eq $? ]; then
					os="Fedora"
					ver=`cat /etc/*release | head -1 | awk '{print $3}'`
				else
					os="Unknown"
				fi
			fi
		fi
	fi
	distName=$os-$ver
}

## The Architecture is checked.  (return archName)
##
checkArchitecture () {
	#Select Architecte
	checkArchName=`uname -m`

	case "$checkArchName" in
		"i386" | "i486")
			archName="i386"
			;;
		"i586" | "i686")
			archName="i586"
			;;
		"amd64" | "x86_64")
			archName="x86_64"
			;;
		*)
			archName=""
			;;
	esac
}


## Packages installation ($1=PackageListFile)
##
packageInstall ()
{
	# Get list filename.
	list="$1"
	status=0

	[ "yes" = "$TEST" ] && echo "* Package list file = ${list}"

	if [ -f "${list}" ] ; then

		packageType=`basename ${list} | sed -e 's,\.list$,,' | awk -F- '{ print $4 }'`

		case "${packageType}" in
			"RPM")
				installCommand="rpm -U"
				[ "yes" = "$TEST" ] && installCommand="rpm -U --test"
				;;
			"DEB")
				installCommand="dpkg -i --no-force-downgrade"
				[ "yes" = "$TEST" ] && installCommand="dpkg --no-act -i --no-force-downgrade"
				;;
			*)
				echo "[ERROR] Fatal error."
				echo "[ERROR] Package installation failed."
				press_enter_key
				exit 255
				;;
		esac

		cd $topDir

		if [ "yes" = "${TEST}" ] ; then
			echo "* Target packages:"
			ls -1 `cat ${list}`
			echo "* Install test:"
			$installCommand `cat ${list}`
			status=0
		else
			for file in `cat ${list}` ; do
				$installCommand "$topDir/$file"
			done
			status=$?
		fi

	else
		echo "[ERROR] cannot access ${list}: No such file."
		echo "[ERROR] Package installation failed."
		press_enter_key
		exit 255
	fi
	return ${status}
}

## get splitted installation package list name (return splitListName)
##
get_splitListName ()
{
	list=`basename $1 | sed -e 's,\.list$,,'`

	dist=`echo ${list} | awk -F- '{ print $1 }' | sed -e 's,_, ,g'`
	rel=`echo ${list} | awk -F- '{ print $2 }'`
	arch=`echo ${list} | awk -F- '{ print $3 }'`
#	pkg=`echo ${list} | awk -F- '{ print $4 }'`

	case "$arch" in
		"i386" | "i486" | "i586" | "i686")
			displayArch="x86(32bit)"
			;;
		"amd64" | "x86_64")
			displayArch="x86_64(64bit)"
			;;
		*)
			displayArch="$arch"
			;;
	esac

	splitListName="${dist} ${rel} ${displayArch}"
}

## User select number (255 is error)
##
get_number ()
{
	read line

	n=`expr "${line}" \* 1 2>/dev/null`
	[ $? -ge 2 ] && return 255

	if [ $n -lt 0 ] ; then
		return 255
	fi

	return $n
}

## select distribution for manual install
##
select_list_file ()
{
	number=0
	endStrings=""

	while true ; do
		echo ""
		echo "Please select your distribution."

		endStrings="Select number [0(cancel)"

		count=0
		for list in `ls -1 $topDir/.install/*.list | LC_ALL=C sort` ; do

			get_splitListName "$list"

			count=`expr $count + 1`

			echo "$count.${splitListName}"

			endStrings="$endStrings/$count"

		done

		echo -n "${endStrings}]? "

		get_number
		number=$?

		if [ 0 -eq $number ] ; then
			echo "Installation canceled."
			press_enter_key
			exit 0
		fi

		if [ ${number} -le ${count} ] ; then

			i=0
			selectedListFile=""
			for list in `ls -1 $topDir/.install/*.list | LC_ALL=C sort` ; do

				i=`expr $i + 1`

				if [ ${number} -eq $i ] ; then
					selectedListFile="$list"
					break ;
				fi
			done

			if [ -n "${selectedListFile}" ] ; then
				break
			fi
		fi

		echo "[ERROR] Please input a correct number."
	done
}

#
# MAIN
#

#check Distribution.
distName=
checkDistribution
[ "yes" = "$TEST" ] && echo "* This distribution is \"${distName}\""

#check Architectur
archName=
checkArchitecture
[ "yes" = "$TEST" ] && echo "* Machine Architecture is \"${archName}\""

#get package list file name
targetFile=`ls -1 $topDir/.install/$distName-$archName-*.list 2> /dev/null`

if [ -n "$targetFile" -a -f "$targetFile" ] ; then

	while true ; do

		get_splitListName "${targetFile}"

		echo -n "Install ${package_name} into ${splitListName} [y/n]? "
		read a

		answer="`echo $a | tr A-Z a-z`"

		case "$answer" in
			"y" | "yes" )
				# take default action
				break
				;;
			"n" | "no"  )
			    # manual installation, selecting distribution
				select_list_file
				targetFile="${selectedListFile}"
				break
				;;
			* )
				echo "[ERROR] Please enter \"y\" or \"n\"."
				;;
		esac
	done
else
	select_list_file
	targetFile="${selectedListFile}"
fi

#Do Packages installation
packageInstall ${targetFile}

#Show finishing message and wait Enter Key
echo ""
if test "no" == "${TEST}" ; then
	echo "*** The installation finished. ***"
else
	echo "*** The installation test finished. ***"
fi
echo ""
press_enter_key

# end of file
