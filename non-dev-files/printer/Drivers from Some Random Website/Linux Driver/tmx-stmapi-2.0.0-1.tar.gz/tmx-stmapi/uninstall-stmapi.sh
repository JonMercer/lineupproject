#!/bin/bash

#set -x
LC_ALL=C
export LC_ALL

# Status monitor API name
stmapiname="TM/BA Series Printer Status Monitor API for Linux"
stmapiver="Ver.2.0.0"
package_name="tmx-stmapi-2.0.0-1"

# Uninstall target
target_packages="
    tmx-stmapi
"

# Interval (sec)
sleep_sec=0


version ()
{
    cat <<EOF
`basename $0`  for "${stmapiname}"  ${stmapiver}
  Copyright (C) 2014 Seiko Epson Corporation. All rights reserved.

EOF
}

press_enter_key ()
{
    echo -n "Press the Enter key."
    read REPLY
}

usage ()
{
cat <<EOF

Package uninstaller for "${stmapiname}"
Target Package:${package_name}

usage: `basename $0` [option]

  option:
	-t | --test    Test mode          (do not uninstall)
	-h | --help    Show help message  (do not uninstall)
	-u | --usage   Show usage message (do not uninstall)
	-v | --version Show version info  (do not uninstall)

uninstalled packages:  ${target_packages}

EOF
}

# execute simple optional action, setting TEST option flag
TEST="no"
for a in $* ; do
    case "$a" in
		"-t" | "--test"    ) TEST="yes" ;;
		"-h" | "--help"    ) version ; usage ; exit 0 ;;
		"-u" | "--usage"   )           usage ; exit 0 ;;
		"-v" | "--version" ) version ;         exit 0 ;;
		"--") break ;;
		*) echo "[ERROR] Unknown option."; exit 255 ;;
    esac
done

check_command ()
{
    which "$1" 1>/dev/null 2>&1
}

# check package management system.
default_packager=""

for cmd in rpm dpkg ; do
    check_command $cmd
    if test $? -eq 0 ; then
		default_packager=$cmd
    fi
done
if test -z ${default_packager} ; then
    echo "[ERROR] Fatal error."
    press_enter_key
    exit 255
fi

# check installed package.
uninstaller=""

for cmd in rpm dpkg ; do
    check_command $cmd
    if test $? -eq 0 ; then
		if test "rpm" = "$cmd" ; then
			option="-q"
		else
			option="-l"
		fi
		for package in ${target_packages} ; do
			$cmd ${option} ${package} 1>/dev/null 2>&1
			if test $? -eq 0 ; then
			uninstaller=$cmd
			break
			fi
		done
		test "" != "${uninstaller}" && break
    fi
done

if test "" = "${uninstaller}" ; then
    uninstaller=${default_packager}
fi

# Change root.
if test 0 -ne `id -u`; then
    echo "Running the sudo command..."
    sudo "$0" $*
    result=$?
    if test 1 -eq $result; then
		echo ""
		echo "[ERROR] The sudo command failed."
		echo "[ERROR] Please execute the `basename $0` again after changing to the root."
		press_enter_key
    fi
    exit $result
fi

# user confirm.
if test "no" = "${TEST}" ; then
	while true ; do
		echo -n "Uninstall ${package_name}  [y/n]? "
		read a
		answer="`echo $a | tr A-Z a-z`"
		case "$answer" in
			"y" | "yes" ) break ;;
			"n" | "no" )
				echo "Uninstallation canceled."
				press_enter_key
				exit 0 ;;
			* ) echo "[ERROR] Please enter \"y\" or \"n\"." ;;
		esac
    done
fi


# set uninstaller option.
if test "rpm" = "${uninstaller}" ; then
    if test "no" = "${TEST}" ; then
        option="-e"
    else
        option="-e --test"
    fi
else
    if test "no" = "${TEST}" ; then
        option="-P"
    else
        option="--no-act -P"
    fi
fi

# Do uninstall.
if test "no" = "${TEST}" ; then
	# uninstall target_packages
    for package in ${target_packages} ; do
		echo "${uninstaller} ${option} ${package}"
		${uninstaller} ${option} ${package}
		sleep ${sleep_sec}
    done
else
	# test mode; only display messages
	echo "* default_packager=${default_packager}"
	echo "* uninstaller=${uninstaller} ${option}"
    echo "* Target packages: ${target_packages}"
    echo "* Uninstall test:"
    ${uninstaller} ${option} ${target_packages}
fi

echo ""
if test "no" = "${TEST}" ; then
	echo "*** The uninstallation finished. ***"
else
	echo "*** The uninstallation test finished. ***"
fi
echo ""
press_enter_key

# end of file
