Status Monitor API マニュアル
（"TM/BAシリーズプリンタードライバー for Linux"用）

目次
1. 使用許諾契約
2. 製品の説明
3. インストール
4. アンインストール
5. 注意／制限事項
6. 旧バージョンからの変更点


------------------------------------------------------------------------
1. 使用許諾契約
------------------------------------------------------------------------

本パッケージは、non-free proprietary license に基づき配布します。
本ライセンスの内容は、添付の EULA.txt を参照してください。


------------------------------------------------------------------------
2. 製品の説明
------------------------------------------------------------------------

本ソフトウェアは、 TM/BAシリーズプリンタードライバー for Linux 用の
ステータス監視 API です。印刷機能を持ったアプリケーションに、高度な
プリンターを監視する機能を組み込むことができます。

2.1. サポート機種

本ソフトウェアは、TM/BAシリーズプリンタードライバー for Linux で使用
可能な機種をすべてサポートします。
詳細については、TM/BAシリーズプリンタードライバー for Linux のマニュアル
をご確認ください。


2.2. サポートインターフェース

サポートするインターフェースについては、TM/BAシリーズプリンタードライバー 
for Linux と同等です。
本ソフトウェアは、プリンターとの接続に、TM/BAシリーズプリンタードライバー 
for Linux と同じく、専用のポート通信モジュール(PCS: EPSON Port 
Communication Service)を使用しております。


2.3. 動作環境

本ソフトウェアは、以下の環境をサポートしています。
サポート環境以外での動作については保証致しません。

* Operating System
  - openSUSE 11.1
  - openSUSE 12.2
  - Ubuntu 9.04
  - Ubuntu 12.04

* Hardware:
  - Intel x86(32bit) architecture.
  - Intel x64(64bit) architecture.


2.4. 動作に必要なソフトウェア

本ソフトウェアが必要とするソフトウェアを以下に示します。
本ソフトウェアをインストールする前に以下のソフトウェアをインストールして下さい。

* CUPS Ver.1.2 以降
      <http://www.cups.org/>

* ポート通信モジュール PCS(EPSON Port Communication Service)
  Ver.3.8.0 以降

* TM/BAシリーズプリンタードライバー for Linux Ver.2.0.0.0 以降


2.5. パッケージの内容

    non-free proprietary license modules:
        32-bit:
            /usr/lib/libEpsStmApi.so
            /usr/lib/libEpsStmPosData.so

        64-bit:
            /usr/lib64/libEpsStmApi.so
            /usr/lib64/libEpsStmPosData.so

    Documents:
        README.ja.txt (日本語)
        README.en.txt (英語)

    License files:
        EULA.ja.txt (日本語)
        EULA.en.txt (英語)

------------------------------------------------------------------------
3. インストール
------------------------------------------------------------------------

本ソフトウェアのインストール方法を以下に示します。

  * install-stmapi.shを実行します。

    ファイルマネージャー等よりinstall-stmapi.shのアイコンをダブルクリック
    するか、インストールパッケージを展開したディレクトリーに移動して、
    コマンドプロンプトより以下のように実行してください。
    # ./install-stmapi.sh

  注）
    ! インストール作業には、root 権限が必要です。
      root以外で実行した場合は、install-stmapi.shによりsudoコマンドが
      実行されますので、パスワードを入力してください。
    ! ドライバーをインストールする前に、プリンターの電源をOFFにしてください。

  * 以前のバージョンがインストールされている場合は、最初に以前のバージョンを
    アンインストールする必要があります。以前のバージョンが検出されると、
    その詳細情報が表示され、アンインストールするか確認するメッセージ
    が表示されます。問題なければ"y"を入力後、Enterキーを押下してください。
    
    例）以下のようなメッセージが表示されます。
    Incompatible version of TM/BA series printer status monitor API found!
    Before the installation, package:"epson-stmapi" must be uninstalled.
      Packages to be uninstalled:
        epson-stmapi-1.0.0-4
    
    Uninstall the incompatible status monitor API: epson-stmapi  [y/n]? y
    ...（略）

  * 環境判別後に、インストールするパッケージとディストリビューションの情報が
    表示されます。間違いなければ"y"を入力後、Enterキーを押下してください。

    例) openSUSE 11.1 x86(32bit) architecture の場合のメッセージ
    Install tmx-stmapi-2.0.0-1 into openSUSE 11.1 x86(32bit) [y/n]? 

  * 表示されたディストリビューションが、インストールされているものと異なる
    場合は、"n"を入力後、Enterキーを押すとディストリビューションの選択画面が
    表示されます。1～8の数字を入力後、Enterキーを押下してください。
    もしインストールをキャンセルする場合は、"0" を入力後 Enter キーを押下してください。

    Please select your distribution.
    1.Ubuntu 12.04 x86(32bit)
    2.Ubuntu 12.04 x86_64(64bit)
    3.Ubuntu 9.04 x86(32bit)
    4.Ubuntu 9.04 x86_64(64bit)
    5.openSUSE 11.1 x86(32bit)
    6.openSUSE 11.1 x86_64(64bit)
    7.openSUSE 12.2 x86(32bit)
    8.openSUSE 12.2 x86_64(64bit)
    Select number [0(cancel)/1/2/3/4/5/6/7/8]?

  * ディストリビューションを選択すると、インストールが実行されます。


------------------------------------------------------------------------
4. アンインストール
------------------------------------------------------------------------

本ソフトウェアをアンインストールする方法を以下に示します。

  パッケージを展開したディレクトリーに移動して、シェルスクリプト 
  uninstall-stmapi.sh を実行します。
  # ./uninstall-stmapi.sh

  注）
    ! アンインストール作業には、root権限が必要です。


------------------------------------------------------------------------
5. 注意／制限事項
------------------------------------------------------------------------

- StatusAPI を使用する前に、CUPS に TM/BAシリーズ プリンターを登録して
  ください。


------------------------------------------------------------------------
6. 旧バージョンからの変更点
------------------------------------------------------------------------

* Ver. 2.0.0

  - 以下のプリンターをサポートしました:
  ［TM汎用モデル］
    - TM/BA汎用サーマルプリンター
    - TM汎用ドットインパクトレシートプリンター
    - TM汎用スリッププリンター
  ［TM汎用モデルによるサポート対象機種］
    - TM-H6000II (レシート, スリップ)
    - TM-H6000III (レシート, スリップ)
    - TM-H6000IV (レシート, スリップ)
    - TM-T70
    - TM-T70 ANK
    - TM-T90
    - TM-T90 ANK
    - TM-T90II
    - TM-U120
    - TM-U120II
    - TM-U230
    - TM-U375 (レシート, スリップ)
    - TM-U675 (レシート, スリップ)
  - パッケージ名称を変更しました。（epson-stmapi-* → tmx-stmapi-*）
  - 通信モジュールをPCS(Port Comminication Service)に変更しました。
  - openSUSE 12.2をサポートしました。
  - Ubuntu 12.04をサポートしました。
  - インストール、アンインストール用スクリプトを用意しました。
    - install-stmapi.sh
    - uninstall-stmapi.sh


* Ver. 1.0.0

  - 新規リリース


------------------------------------------------------------------------
Copyright (C) Seiko Epson Corporation 2010-2014. All rights reserved

Linuxは、Linus Torvalds氏の米国およびその他の国における登録商標または商標です。

CUPSとCUPSロゴは、米国および他の国々で登録されたApple Inc.の商標です。

"Novell" と "openSUSE" は、The openSUSE Project の設立者であり出資者でもある、
同プロジェクトに指名された Novell, Inc. の商標です。

UbuntuとCanonicalはCanonical Ltd.登録商標です。

そのほかの製品名は各社の商標または登録商標です。 
