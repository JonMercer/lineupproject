
#include "StatusAPI.h"
#include <stdio.h>
/*
 * StatusAPI.cpp
 * Function definitions for components of the Status API
 */

CStatusAPI::CStatusAPI() {
	// Initialize all to NULL
	m_hDll                          = NULL;
	m_funcBiOpenMonPrinter			= NULL;
	m_funcBiCloseMonPrinter			= NULL;
	m_funcBiLockPrinter				= NULL;
	m_funcBiUnlockPrinter			= NULL;
	m_funcBiDirectIOEx				= NULL;
	m_funcBiResetPrinter			= NULL;
	m_funcBiGetStatus				= NULL;
	m_funcBiSetStatusBackFunctionEx2= NULL;
	m_funcBiCancelStatusBack		= NULL;
	m_funcBiGetCounter				= NULL;
	m_funcBiResetCounter			= NULL;
}

CStatusAPI::~CStatusAPI(void) {
	if ( m_hDll != NULL ) {
            dlclose(m_hDll);
	}
}

BOOL	CStatusAPI::Initialize() {
	/*
	 * Load the Status API DLL
	 */
	m_hDll = dlopen(STATUS_API_FILE, RTLD_NOW);

	if ( m_hDll != NULL ) {
		// Load the necessary functions for this application
		m_funcBiOpenMonPrinter
			= (DLL_BiOpenMonPrinter)dlsym(m_hDll, "BiOpenMonPrinter");
		m_funcBiCloseMonPrinter
			= (DLL_BiCloseMonPrinter)dlsym(m_hDll, "BiCloseMonPrinter");
		m_funcBiLockPrinter
			= (DLL_BiLockPrinter)dlsym(m_hDll, "BiLockPrinter");
		m_funcBiUnlockPrinter
			= (DLL_BiUnlockPrinter)dlsym(m_hDll, "BiUnlockPrinter");
		m_funcBiDirectIOEx
			= (DLL_BiDirectIOEx)dlsym(m_hDll, "BiDirectIOEx");
		m_funcBiResetPrinter
			= (DLL_BiResetPrinter)dlsym(m_hDll, "BiResetPrinter");
		m_funcBiGetStatus
			= (DLL_BiGetStatus)dlsym(m_hDll, "BiGetStatus");
		m_funcBiSetStatusBackFunctionEx2
			= (DLL_BiSetStatusBackFunctionEx2)dlsym(m_hDll, "BiSetStatusBackFunctionEx2");
		m_funcBiCancelStatusBack
			= (DLL_BiCancelStatusBack)dlsym(m_hDll, "BiCancelStatusBack");
		m_funcBiGetCounter
			= (DLL_BiGetCounter)dlsym(m_hDll, "BiGetCounter");
		m_funcBiResetCounter
			= (DLL_BiResetCounter)dlsym(m_hDll, "BiResetCounter");

		if ((m_funcBiOpenMonPrinter != NULL) &&
			(m_funcBiCloseMonPrinter != NULL) &&
			(m_funcBiLockPrinter != NULL) &&
			(m_funcBiUnlockPrinter != NULL) &&
			(m_funcBiDirectIOEx != NULL) &&
			(m_funcBiResetPrinter != NULL) &&
			(m_funcBiGetStatus != NULL) &&
			(m_funcBiSetStatusBackFunctionEx2 != NULL) &&
			(m_funcBiCancelStatusBack != NULL) &&
			(m_funcBiGetCounter != NULL) &&
			(m_funcBiResetCounter !=NULL) ) {
			return TRUE;
		}
		else {
			return FALSE;
		}
	}
	else {
	    const char* strDLLError = dlerror();
	    puts(strDLLError);
		return FALSE;
	}
}

int		CStatusAPI::BiOpenMonPrinter(int nType, LPSTR pName) {
	if (  m_funcBiOpenMonPrinter!=NULL ) {
		return m_funcBiOpenMonPrinter(nType, pName);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiCloseMonPrinter(int nHandle)
{
	if (  m_funcBiCloseMonPrinter!=NULL  ) {
		return m_funcBiCloseMonPrinter(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiLockPrinter(int nHandle, DWORD timeout)
{
	if (  m_funcBiLockPrinter != NULL )
	{
		return m_funcBiLockPrinter(nHandle, timeout);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiUnlockPrinter(int nHandle)
{
	if ( m_funcBiUnlockPrinter != NULL  )
	{
		return m_funcBiUnlockPrinter(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiDirectIOEx(int nHandle, DWORD writeLen, LPBYTE writeCmd, LPDWORD readLen, LPBYTE readBuff,
								 DWORD timeout,BOOL nullTerminate, BYTE option)
{
	if ( m_funcBiDirectIOEx != NULL  )
	{
		return m_funcBiDirectIOEx(nHandle, writeLen, writeCmd, readLen, readBuff,
									timeout, nullTerminate, option);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiResetPrinter(int nHandle)
{
	if (  m_funcBiResetPrinter != NULL  ) {
		return m_funcBiResetPrinter(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiGetStatus(int nHandle, LPDWORD lpStatus)
{
	if (  m_funcBiGetStatus!=NULL  ) {
		return m_funcBiGetStatus(nHandle, lpStatus);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiSetStatusBackFunctionEx2(int nHandle, int (CALLBACK EXPORT *pStatusCB )(DWORD dwStatus, LPVOID lpParam), LPVOID lpParam)
{
	if (  m_funcBiSetStatusBackFunctionEx2 != NULL  ) {
		return m_funcBiSetStatusBackFunctionEx2 (nHandle, pStatusCB, lpParam);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiCancelStatusBack(int nHandle)
{
	if (  m_funcBiCancelStatusBack != NULL  ) {
		return m_funcBiCancelStatusBack(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiGetCounter(int nHandle, WORD readno, LPDWORD readcounter)
{
	if ( m_funcBiGetCounter != NULL  )
	{
		return m_funcBiGetCounter(nHandle, readno, readcounter);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiResetCounter(int nHandle, WORD writeno)
{
	if ( m_funcBiResetCounter != NULL  )
	{
		return m_funcBiResetCounter(nHandle, writeno);
	}
	return ERR_NO_PRINTER;
}

