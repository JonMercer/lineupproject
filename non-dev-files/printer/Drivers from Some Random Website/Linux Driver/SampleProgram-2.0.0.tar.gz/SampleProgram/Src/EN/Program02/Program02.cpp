/** @file Program02.cpp
 *     @brief Sample program that demonstrates error handling.
 *
 *     @version 1.0, 01.27.2010
 *
 *//* ***************************************************************************************** */
/** @addtogroup StatusAPI SampleProgram
 * @{
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <termios.h>
#include <unistd.h>
#include "StatusAPI.h"

#define MYASB	(ASB_NO_RESPONSE | ASB_COVER_OPEN | ASB_AUTOCUTTER_ERR | ASB_RECEIPT_NEAR_END | ASB_RECEIPT_END | ASB_UNRECOVER_ERR)

int myGetch()
{
        struct termios oldTerm, newTerm;
        int ch;

        tcgetattr( STDIN_FILENO, &oldTerm );
        newTerm = oldTerm;
        newTerm.c_lflag &= ~( ICANON | ECHO );
        tcsetattr( STDIN_FILENO, TCSANOW, &newTerm );

        do{
                ch = getchar();
        } while(ch=='\n');

        tcsetattr( STDIN_FILENO, TCSANOW, &oldTerm );

        return ch;
}

void ReadStringInput(char* strBuffer, size_t nBufferSize)
{
	/* Validate the parameters */
	if((strBuffer != NULL) &&
		(nBufferSize > 0))
	{
		size_t nStrLen;
		fgets(strBuffer, nBufferSize, stdin);
		/* Make sure the string is NULL-terminated */
		strBuffer[nBufferSize - 1] = '\0';
		/* Remove the '\n' character automatically appended by fgets  */
		nStrLen = strlen(strBuffer);
		if(	(nStrLen > 0) &&
			('\n' == strBuffer[nStrLen - 1]))
		{
			strBuffer[nStrLen - 1] = '\0';
		}
	}
}

void PrintPrinterStatus(DWORD dwPrinterStatus)
{
	/* Evaluate printer status */
	if (dwPrinterStatus & ASB_NO_RESPONSE) {
		printf("\nNo response.");
	} else if (dwPrinterStatus & ASB_COVER_OPEN) {
		printf("\nCover is open.");
	} else if (dwPrinterStatus & ASB_AUTOCUTTER_ERR) {
		printf("\nAutocutter error occured.");
	} else if (dwPrinterStatus & (ASB_RECEIPT_NEAR_END | ASB_RECEIPT_END)) {
		printf("\nRoll paper end sensor: paper not present.");
	} else if (dwPrinterStatus & ASB_UNRECOVER_ERR) {
		printf("\nAn unrecoverable error has occurred. Resetting printer");
	}
}

int main(int argc, char **argv)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/
	CStatusAPI oStsAPI; /* StatusAPI object */
	int nHandle = 0; /* Printer handle */
	bool bIsInitialized; /* Flag if StatusAPI was initialized successfully */
	int nType; /* Type when opening the printer */
	char strName[128]; /* Name of the port/printer */
	DWORD dwPrnStatus; /* Status of the printer */
	int nAPIResult; /* Result of StatusAPI call */
	int iKeyPressed; /* Key pressed */
	char strStringInput[64];	/* String input of the user */
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* Initialize API */
	bIsInitialized = oStsAPI.Initialize();
	if (FALSE == bIsInitialized) {
		printf("Failed to open StatusAPI.\n");
		return (EXIT_FAILURE);
	}

	/* Get input from user for nType and strName */
	do {
		printf("\nPlease enter type [TYPE_PORT(1)/TYPE_PRINTER(2)]: ");
		nType = 0;	/* Initialize to invalid type */
		ReadStringInput(strStringInput, sizeof(strStringInput));	/* Read user input and store in memory */
		sscanf(strStringInput, "%d", &nType);	/* Parse the string in memory and get the number */
	} while ((nType != TYPE_PORT) && (nType != TYPE_PRINTER));

	if (nType == TYPE_PORT) {
		printf("\nPlease enter port name: ");
	} else if (nType == TYPE_PRINTER) {
		printf("\nPlease enter printer name: ");
	}

	ReadStringInput(strName, sizeof(strName));

	nHandle = oStsAPI.BiOpenMonPrinter(nType, strName);

	if (nHandle <= 0) {
		printf("\nFailed to open printer status monitor.\n");
		return (EXIT_FAILURE);
	} else {
		printf("\nPrinter status monitor is started.");
	}

	printf("\nChange printer status (ex: Open Cover, Remove rolled paper....)\n");

	/* Check for printer status. Break from loop when user inputs 'Q'/'q'. */
	do {
		/* Get printer status while it is ASB_DRAWER_KICK. */
		do {
			nAPIResult = oStsAPI.BiGetStatus(nHandle, &dwPrnStatus);
			if (nAPIResult != SUCCESS) {
				printf("\nFailed to get status.");
				break;
			}
		} while (!(dwPrnStatus & MYASB));

		PrintPrinterStatus(dwPrnStatus);

		/* Reset printer if there's an unrecoverable error */
		if (dwPrnStatus & ASB_UNRECOVER_ERR) {
			nAPIResult = oStsAPI.BiResetPrinter(nHandle);
			if (nAPIResult != SUCCESS) {
				printf("\nFailed to reset printer.");
			}
		}

		/* Wait for user key input */
		printf("\nContinue? (Q to quit/Any character to continue): ");

		iKeyPressed = toupper(myGetch());
		if(isprint(iKeyPressed))
		{
			putchar(iKeyPressed);
		}

		printf("\n");
	} while (iKeyPressed != 'Q');

	/* Always close the Status Monitor after using the Status API */
	nAPIResult = oStsAPI.BiCloseMonPrinter(nHandle);
	if (nAPIResult != SUCCESS) {
		printf("\nFailed to close printer status monitor.");
	}

	printf("\n");

	return (EXIT_SUCCESS);
}

/** @} **/


