/** @file Program05.h
*     @brief Header file of the sample program that demonstrates BiLockPrinter/BiUnlockPrinter.
*
*     @version 1.0, 01.28.2010
*     @author Efren Duran Jr.
*
* Copyright (c) 2007-2008 SEIKO EPSON CORPORATION. All Rights Reserved.
*//* ***************************************************************************************** */
/** @addtogroup StatusAPI SampleProgram
* @{
*/

#ifndef _PROGRAM05_H
#define	_PROGRAM05_H

#include "StatusAPI.h"


void *Step5(void *param);


#endif	/* _PROGRAM05_H */

/** @} **/


