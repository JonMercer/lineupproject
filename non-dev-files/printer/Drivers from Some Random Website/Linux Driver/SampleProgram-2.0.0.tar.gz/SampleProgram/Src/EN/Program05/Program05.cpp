/** @file Program05.cpp
 *     @brief Sample program that demonstrates BiLockPrinter/BiUnlockPrinter.
 *
 *     @version 1.0, 01.28.2010
 *
 *//* ***************************************************************************************** */
/** @addtogroup StatusAPI SampleProgram
 * @{
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include "Program05.h"

/* @brief StatusAPI object */
CStatusAPI g_oStsAPI;

void ReadStringInput(char* strBuffer, size_t nBufferSize)
{
	/* Validate the parameters */
	if((strBuffer != NULL) &&
		(nBufferSize > 0))
	{
		size_t nStrLen;
		fgets(strBuffer, nBufferSize, stdin);
		/* Make sure the string is NULL-terminated */
		strBuffer[nBufferSize - 1] = '\0';
		/* Remove the '\n' character automatically appended by fgets  */
		nStrLen = strlen(strBuffer);
		if(	(nStrLen > 0) &&
			('\n' == strBuffer[nStrLen - 1]))
		{
			strBuffer[nStrLen - 1] = '\0';
		}
	}
}

void PrintCharacters(int nHandle)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~*/
	int nCounter;
	int nPrintCount = 0;
	int nAPIResult;
	DWORD dwWritelen;
	DWORD dwReadlen = 0;
	BYTE byReadBuff;
	DWORD dwTimeout = 3000;
	BOOL bNullTerminate = TRUE;
	BYTE byOption = 0;
	char strBuff[128 + 2];
	char strStringInput[64];
	/*~~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* The last 2 bytes of strbuff are reserved for '\n' and '\0' characters */
	printf("Input the string to be printed(maximum length is %u): ", (unsigned int)(sizeof(strBuff) - 2));
	/* fgets must be used instead of scanf("%s") to avoid memory leak */
	fgets(strBuff, sizeof(strBuff), stdin);
	/* Make sure the string has next line and a NULL-termination characters */
	strBuff[sizeof(strBuff) - 2] = '\n';
	strBuff[sizeof(strBuff) - 1] = '\0';

	printf("Input how many times the string be printed: ");
	ReadStringInput(strStringInput, sizeof(strStringInput));	/* Read user input and store in memory */
	sscanf(strStringInput, "%d", &nPrintCount);	/* Parse the string in memory and get the number */

	dwWritelen = strlen(strBuff);

	/* Lock Printer */
	do {
		nAPIResult = g_oStsAPI.BiLockPrinter(nHandle, 3000);
	} while (nAPIResult != SUCCESS);

	/* Print a string using BiDirectIOEx */
	for (nCounter = 1; nCounter <= nPrintCount; nCounter++) {
		nAPIResult = g_oStsAPI.BiDirectIOEx(nHandle,
											dwWritelen,
											(LPBYTE) strBuff,
											&dwReadlen,
											&byReadBuff,
											dwTimeout,
											bNullTerminate,
											byOption);
	}

	/* Unlock Printer */
	nAPIResult = g_oStsAPI.BiUnlockPrinter(nHandle);
	if (nAPIResult != SUCCESS) {
		printf("Failed to unlock printer.\n");
	}
}

void *Step5(void *param)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/
	int nHandle = 0; /* Printer handle */
	int nType; /* Type when opening the printer */
	int nAPIResult; /* Result of StatusAPI call */
	bool bIsInitialized; /* Flag if StatusAPI was initialized successfully */
	char strName[128]; /* Name of the port/printer */
	char strStringInput[64];	/* String input of the user */
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* Initialize API */
	bIsInitialized = g_oStsAPI.Initialize();
	if (FALSE == bIsInitialized) {
		printf("Failed to open StatusAPI.\n");
		return NULL;
	}

	/* Get input from user for nType and strName */
	do {
		printf("Please enter type [TYPE_PORT(1)/TYPE_PRINTER(2)]: ");
		nType = 0;	/* Initialize to invalid type */
		ReadStringInput(strStringInput, sizeof(strStringInput));	/* Read user input and store in memory */
		sscanf(strStringInput, "%d", &nType);	/* Parse the string in memory and get the number */
	} while ((nType != TYPE_PORT) && (nType != TYPE_PRINTER));

	if (nType == TYPE_PORT) {
		printf("Please enter port name: ");
	} else if (nType == TYPE_PRINTER) {
		printf("Please enter printer name: ");
	}

	ReadStringInput(strName, sizeof(strName));

	nHandle = g_oStsAPI.BiOpenMonPrinter(nType, strName);

	if (nHandle <= 0) {
		printf("Failed to open printer status monitor.\n");
		return NULL;
	} else {
		printf("Printer status monitor is started.\n");
	}

	/* Make sure all the strings are displayed to stdout */
	fflush(stdout);

	PrintCharacters(nHandle);

	/* Always close the Status Monitor after using the Status API */
	nAPIResult = g_oStsAPI.BiCloseMonPrinter(nHandle);
	if (nAPIResult != SUCCESS) {
		printf("Failed to close printer status monitor.\n");
	}

	return NULL;
}

int main()
{
	pthread_t hThread;
	/** Create child thread */
	pthread_create(&hThread, NULL, Step5, NULL);
	/** Wait for child thread process to finish before exitting*/
	pthread_join(hThread, NULL);
	printf("\n");
	return (EXIT_SUCCESS);
}

/** @} **/


