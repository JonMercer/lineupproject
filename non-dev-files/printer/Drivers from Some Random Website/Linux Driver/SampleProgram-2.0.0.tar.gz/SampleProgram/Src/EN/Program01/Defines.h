#ifdef _WIN32
	#include <windows.h>
#else
	#include <stdint.h>
         #include <stddef.h>

	typedef uint32_t                DWORD;
	typedef int32_t                 BOOL;
	typedef uint8_t                 BYTE;
	typedef uint16_t                WORD;
	typedef char                    CHAR;
	typedef char*					LPSTR, *PSTR;
	typedef int                     INT;

	#ifndef NULL
		#ifdef __cplusplus
			#define NULL    0
		#else
			#define NULL    ((void *)0)
		#endif	// #ifdef __cplusplus
	#endif	// #ifndef NULL

	#ifndef FALSE
		#define FALSE               0
	#endif	// #ifndef FALSE

	#ifndef TRUE
		#define TRUE                1
	#endif	// #ifndef TRUE

	#undef far
	#undef near
	#undef pascal

	#define far
	#define near

	#ifdef _STDCALL_SUPPORTED
		#define pascal __stdcall
	#else
		#define pascal
	#endif	// #ifdef _STDCALL_SUPPORTED

	#ifdef _CDECL_SUPPORTED
		#define cdecl _cdecl
		#ifndef CDECL
			#define CDECL _cdecl
		#endif	// #ifndef CDECL
	#else
		#define cdecl
		#ifndef CDECL
			#define CDECL
		#endif	// #ifndef CDECL
	#endif  // #ifdef _CDECL_SUPPORTED

	#ifdef _MAC
		#define CALLBACK    PASCAL
		#define WINAPI      CDECL
		#define APIENTRY    WINAPI

		#ifdef _68K_
			#define PASCAL      __pascal
		#else
			#define PASCAL
		#endif	// #ifdef _68K_
	#elif defined(_STDCALL_SUPPORTED)
		#define CALLBACK    __stdcall
		#define WINAPI      __stdcall
		#define APIENTRY    WINAPI
		#define PASCAL      __stdcall
	#else
		#define CALLBACK
		#define WINAPI
		#define APIENTRY    WINAPI
		#define PASCAL      pascal
	#endif	// #ifdef _MAC

	#undef FAR
	#undef NEAR
	#define FAR                 far
	#define NEAR                near

	typedef BYTE far            *LPBYTE;
	typedef DWORD far           *LPDWORD;
	typedef void far            *LPVOID;
#endif	// #ifdef _WIN32

