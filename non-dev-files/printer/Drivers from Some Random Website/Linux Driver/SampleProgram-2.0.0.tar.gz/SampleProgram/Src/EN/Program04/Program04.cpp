/** @file Program04.cpp
 *     @brief Sample program that demonstrates maintenance counter retrieval.
 *
 *     @version 1.0, 01.28.2010
 *
 *//* ***************************************************************************************** */
/** @addtogroup StatusAPI SampleProgram
 * @{
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "StatusAPI.h"

void ReadStringInput(char* strBuffer, size_t nBufferSize)
{
	/* Validate the parameters */
	if((strBuffer != NULL) &&
		(nBufferSize > 0))
	{
		size_t nStrLen;
		fgets(strBuffer, nBufferSize, stdin);
		/* Make sure the string is NULL-terminated */
		strBuffer[nBufferSize - 1] = '\0';
		/* Remove the '\n' character automatically appended by fgets  */
		nStrLen = strlen(strBuffer);
		if(	(nStrLen > 0) &&
			('\n' == strBuffer[nStrLen - 1]))
		{
			strBuffer[nStrLen - 1] = '\0';
		}
	}
}

int main(int argc, char **argv)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/
	CStatusAPI oStsAPI; /* StatusAPI object */
	int nHandle = 0; /* Printer handle */
	int nType; /* Type when opening the printer */
	int nAPIResult; /* Result of StatusAPI call */
	bool bIsInitialized; /* Flag if StatusAPI was initialized successfully */
	char strName[128]; /* Name of the port/printer */
	DWORD dwReadcounter; /* Maintenance counter */
	char strStringInput[64];	/* String input of the user */
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* Initialize API */
	bIsInitialized = oStsAPI.Initialize();
	if (FALSE == bIsInitialized) {
		printf("Failed to open StatusAPI.\n");
		return (EXIT_FAILURE);
	}

	/* Get input from user for nType and strName */
	do {
		printf("\nPlease enter type [TYPE_PORT(1)/TYPE_PRINTER(2)]: ");
		nType = 0;	/* Initialize to invalid type */
		ReadStringInput(strStringInput, sizeof(strStringInput));	/* Read user input and store in memory */
		sscanf(strStringInput, "%d", &nType);	/* Parse the string in memory and get the number */
	} while ((nType != TYPE_PORT) && (nType != TYPE_PRINTER));

	if (nType == TYPE_PORT) {
		printf("\nPlease enter port name: ");
	} else if (nType == TYPE_PRINTER) {
		printf("\nPlease enter printer name: ");
	}

	ReadStringInput(strName, sizeof(strName));

	nHandle = oStsAPI.BiOpenMonPrinter(nType, strName);

	if (nHandle <= 0) {
		printf("\nFailed to open printer status monitor.\n");
		return (EXIT_FAILURE);
	} else {
		printf("\nPrinter status monitor is started.");
	}

	/* Make sure all the strings are displayed to stdout */
	fflush(stdout);

	/* Get Maintenance counter (Autocutter activation times) */
	nAPIResult = oStsAPI.BiGetCounter(nHandle, MC_AUTOCUT_OPERATIONS, &dwReadcounter);
	if (nAPIResult != SUCCESS) {
		printf("\nFailed to get counter.");
	} else {
		printf("\nMaintenance counter (Autocutter activation times) is %d.", dwReadcounter);
	}

	/* Always close the Status Monitor after using the Status API */
	nAPIResult = oStsAPI.BiCloseMonPrinter(nHandle);
	if (nAPIResult != SUCCESS) {
		printf("\nFailed to close printer status monitor.");
	}

	printf("\n");
	return (EXIT_SUCCESS);
}

/** @} **/


