/** @file Program03.cpp
 *     @brief Sample program that demonstrates callback registration.
 *
 *     @version 1.0, 01.27.2010
 *
 *//* ***************************************************************************************** */
/** @addtogroup StatusAPI SampleProgram
 * @{
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "StatusAPI.h"
#include <semaphore.h>
#include <unistd.h>

#define MYASB	(ASB_PRINT_SUCCESS | ASB_NO_RESPONSE | ASB_AUTOCUTTER_ERR | ASB_COVER_OPEN | ASB_RECEIPT_NEAR_END | ASB_RECEIPT_END)

typedef struct _ST_USER_PARAM
{
	DWORD dwPrinterStatus;
	sem_t nMutex;
} ST_USER_PARAM;

void ReadStringInput(char* strBuffer, size_t nBufferSize)
{
	/* Validate the parameters */
	if((strBuffer != NULL) &&
		(nBufferSize > 0))
	{
		size_t nStrLen;
		fgets(strBuffer, nBufferSize, stdin);
		/* Make sure the string is NULL-terminated */
		strBuffer[nBufferSize - 1] = '\0';
		/* Remove the '\n' character automatically appended by fgets  */
		nStrLen = strlen(strBuffer);
		if(	(nStrLen > 0) &&
			('\n' == strBuffer[nStrLen - 1]))
		{
			strBuffer[nStrLen - 1] = '\0';
		}
	}
}

void PrintPrinterStatus(DWORD dwPrinterStatus)
{
	/* Notify print completion */
	if (dwPrinterStatus & ASB_PRINT_SUCCESS) {
		printf("\nPrinting complete.");
	}
	/* Notify any errors that occur. */
	if (dwPrinterStatus & ASB_NO_RESPONSE) {
		printf("\nNo response.");
	} else if (dwPrinterStatus & ASB_COVER_OPEN) {
		printf("\nCover is open.");
	} else if (dwPrinterStatus & ASB_AUTOCUTTER_ERR) {
		printf("\nAutocutter error occurred.");
	} else if (dwPrinterStatus & (ASB_RECEIPT_NEAR_END | ASB_RECEIPT_END)) {
		printf("\nRoll paper end sensor: paper not present.");
	}
}

int CALLBACK CBGetStatus(DWORD dwStatus, LPVOID lpParam)
{
	ST_USER_PARAM* pstUserParam = (ST_USER_PARAM*)lpParam;

	/* Get status from printer and store it in user's parameter */
	pstUserParam->dwPrinterStatus = dwStatus;

	/* Evaluate status */
	if(dwStatus & MYASB) {
		/* send signal to waiting semaphore */
		sem_post(&pstUserParam->nMutex);
	}

	return SUCCESS;
}

int main(int argc, char **argv)
{
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/
	CStatusAPI oStsAPI; /* StatusAPI object */
	int nHandle = 0; /* Printer handle */
	bool bIsInitialized; /* Flag if StatusAPI was initialized successfully */
	int nType; /* Type when opening the printer */
	char strName[128]; /* Name of the port/printer */
	int nAPIResult; /* Result of StatusAPI call */
	ST_USER_PARAM stUserParam;	/* User parameter for BiSetStatusBackFunctionEx2 */
	char strStringInput[64];	/* String input of the user */
	/*~~~~~~~~~~~~~~~~~~~~~~~~~*/

	/* Initialize API */
	bIsInitialized = oStsAPI.Initialize();
	if (FALSE == bIsInitialized) {
		printf("Failed to open StatusAPI.\n");
		return (EXIT_FAILURE);
	}

	/* Get input from user for nType and strName */
	do {
		printf("\nPlease enter type [TYPE_PORT(1)/TYPE_PRINTER(2)]: ");
		nType = 0;	/* Initialize to invalid type */
		ReadStringInput(strStringInput, sizeof(strStringInput));	/* Read user input and store in memory */
		sscanf(strStringInput, "%d", &nType);	/* Parse the string in memory and get the number */
	} while ((nType != TYPE_PORT) && (nType != TYPE_PRINTER));

	if (nType == TYPE_PORT) {
		printf("\nPlease enter port name: ");
	} else if (nType == TYPE_PRINTER) {
		printf("\nPlease enter printer name: ");
	}

	ReadStringInput(strName, sizeof(strName));

	nHandle = oStsAPI.BiOpenMonPrinter(nType, strName);

	if (nHandle <= 0) {
		printf("\nFailed to open printer status monitor.\n");
		return (EXIT_FAILURE);
	} else {
		printf("\nPrinter status monitor is started.");
	}

	/* Make sure all the strings are displayed to stdout */
	fflush(stdout);

	/* Initialize semaphore */
	if (sem_init(&stUserParam.nMutex, 0, 0) < 0) {
		printf("\nFailed to open semaphore.");
	}

	/* Register callback function */
	nAPIResult = oStsAPI.BiSetStatusBackFunctionEx2(nHandle, CBGetStatus, &stUserParam);
	if (nAPIResult != SUCCESS) {
		printf("\nFailed to set callback function.");
	}

	/* Wait for the signal event from the callback function */
	sem_wait(&stUserParam.nMutex);

	PrintPrinterStatus(stUserParam.dwPrinterStatus);
	usleep(100 * 1000);

	/* Un-register callback function */
	nAPIResult = oStsAPI.BiCancelStatusBack(nHandle);
	if (nAPIResult != SUCCESS) {
		printf("\nFailed to cancel callback function.");
	}

	/* Always close the Status Monitor after using the Status API */
	nAPIResult = oStsAPI.BiCloseMonPrinter(nHandle);
	if (nAPIResult != SUCCESS) {
		printf("\nFailed to close printer status monitor.");
	}

	/* Destroy semaphore */
	sem_destroy(&stUserParam.nMutex);
	printf("\n");
	return (EXIT_SUCCESS);
}

/** @} **/


