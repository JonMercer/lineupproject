#pragma once
#include "Defines.h"
///////////////////////////////////////////////////////////////////////////////
// ERROR CODE :
typedef int SA_RESULT;
#define		SUCCESS						0				// Success
#define		ERR_NO_PRINTER				-30				// There is not printer driver

#define		ASB_NO_RESPONSE				0x00000001UL	//No response
#define		ASB_PRINT_SUCCESS			0x00000002UL	//Finish to print
#define		ASB_DRAWER_KICK				0x00000004UL	//Drawer kick-out connector pin3 is HIGH
#define		ASB_COVER_OPEN				0x00000020UL	//Cover is open
#define		ASB_AUTOCUTTER_ERR			0x00000800UL	//Auto cutter error
#define		ASB_UNRECOVER_ERR			0x00002000UL	//Unrecoverable error
#define		ASB_RECEIPT_NEAR_END		0x00020000UL	//Receipt paper roll near-end
#define		ASB_RECEIPT_END				0x00080000UL	//Receipt paper roll end

///////////////////////////////////////////////////////////////////////////////
// BiOpenMonPrinter() :

// Type
#define		TYPE_PORT					1				// use port name
#define		TYPE_PRINTER				2				// use printer driver name

#ifndef EXPORT
	#define EXPORT
#endif

//Standard
typedef SA_RESULT (APIENTRY* DLL_BiOpenMonPrinter)(INT, LPSTR);
typedef SA_RESULT (APIENTRY* DLL_BiCloseMonPrinter)(INT);
typedef SA_RESULT (APIENTRY* DLL_BiLockPrinter)(INT, DWORD);
typedef SA_RESULT (APIENTRY* DLL_BiUnlockPrinter)(INT);
typedef SA_RESULT (APIENTRY* DLL_BiDirectIOEx)(INT, DWORD, LPBYTE, LPDWORD, LPBYTE, DWORD, BOOL, BYTE);
typedef SA_RESULT (APIENTRY* DLL_BiResetPrinter)(INT);
typedef SA_RESULT (APIENTRY* DLL_BiGetStatus)(INT, LPDWORD);
typedef SA_RESULT (APIENTRY* DLL_BiSetStatusBackFunctionEx2)(INT, INT (CALLBACK EXPORT *pStatusCB)(DWORD, LPVOID), LPVOID);
typedef SA_RESULT (APIENTRY* DLL_BiCancelStatusBack)(INT);
typedef SA_RESULT (APIENTRY* DLL_BiGetCounter)(INT, WORD, LPDWORD);
typedef SA_RESULT (APIENTRY* DLL_BiResetCounter)(INT, WORD);

