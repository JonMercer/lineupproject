/*
StatusAPI.h

Class definition for Status API. Includes the functions required for CompletionDialog
*/

#ifndef	_STATUS_API
#define _STATUS_API

#include "EpsStmApi.h"
#include <dlfcn.h>

#define STATUS_API_FILE	"libEpsStmApi.so"

#define MC_AUTOCUT_OPERATIONS	0x32

class CStatusAPI {
protected:
	// Handle to a DLL
    void* m_hDll;

private:
	// Function pointers
	DLL_BiOpenMonPrinter	m_funcBiOpenMonPrinter;
	DLL_BiCloseMonPrinter	m_funcBiCloseMonPrinter;
	DLL_BiLockPrinter		m_funcBiLockPrinter;
	DLL_BiUnlockPrinter		m_funcBiUnlockPrinter;
	DLL_BiDirectIOEx		m_funcBiDirectIOEx;
	DLL_BiResetPrinter		m_funcBiResetPrinter;
	DLL_BiGetStatus			m_funcBiGetStatus;
	DLL_BiSetStatusBackFunctionEx2	m_funcBiSetStatusBackFunctionEx2;
	DLL_BiCancelStatusBack	m_funcBiCancelStatusBack;
	DLL_BiGetCounter		m_funcBiGetCounter;
	DLL_BiResetCounter		m_funcBiResetCounter;

public:
	// Constructor and Destructor
	CStatusAPI(void);
	virtual ~CStatusAPI();

	// Public API Functions. Must call Initialize() before anything else
	BOOL	Initialize();
	int BiOpenMonPrinter(int nType, LPSTR pName);
	int BiCloseMonPrinter(int nHandle);
	int	BiLockPrinter(int nHandle, DWORD timeout);
	int	BiUnlockPrinter(int nHandle);
	int BiDirectIOEx(int nHandle, DWORD writeLen, LPBYTE writeCmd, LPDWORD readLen, LPBYTE readBuff, DWORD timeout,BOOL nullTerminate, BYTE option);
	int BiResetPrinter(int nHandle);
	int BiGetStatus(int nHandle, LPDWORD lpStatus);
	int BiSetStatusBackFunctionEx2 (int nHandle, int (CALLBACK EXPORT *pStatusCB )(DWORD dwStatus, LPVOID lpParam), LPVOID lpParam);
	int	BiCancelStatusBack(int nHandle);
	int BiGetCounter(int nHandle, WORD readno, LPDWORD readcounter);
	int BiResetCounter(int nHandle, WORD writeno);
};

#endif

