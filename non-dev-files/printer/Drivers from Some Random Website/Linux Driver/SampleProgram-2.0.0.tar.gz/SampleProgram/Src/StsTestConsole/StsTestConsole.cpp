/** @file StsTestConsole.cpp
 *     @brief Sample program for call each function of StatusAPI.
 *
 *     @version 1.0, 02.20.2014
 *
 *//* ***************************************************************************************** */
#include "StatusAPI.h"

#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <termios.h>
#include <stdlib.h>

typedef enum _COMMAND
{
	QUIT = 0,
	BIOPENMONPRINTER = 1,
	BICLOSEMONPRINTER,
	BILOCKPRINTER,
	BIUNLOCKPRINTER,
	BIDIRECTIOEX,
	BIRESETPRINTER,
	BIGETSTATUS,
	BISETSTATUSBACKFUNCTIONEX2,
	BICANCELSTATUSBACK,
	BIGETCOUNTER,
	BIRESETCOUNTER,
	BIOPENDRAWER,
	BISCNCLAMPPAPER,
	BIFORCERESETPRINTER,
	BIGETEXTENDSTATUS,
	PRINTLINE,
	PRINTFILE,
} COMMAND;

typedef struct _BIOPENMONPRINTER_PARAM
{
	int nHandle;	// place holder
	int nType;
	char strName[128];
} BIOPENMONPRINTER_PARAM;

typedef struct _BICLOSEMONPRINTER_PARAM
{
	int nHandle;
} BICLOSEMONPRINTER_PARAM;

typedef struct _BILOCKPRINTER_PARAM
{
	int nHandle;
	DWORD dwTimeout;
} BILOCKPRINTER_PARAM;

typedef struct _BIUNLOCKPRINTER_PARAM
{
	int nHandle;
} BIUNLOCKPRINTER_PARAM;

typedef struct _BIGETSTATUS_PARAM
{
	int nHandle;
	DWORD dwStatus;
} BIGETSTATUS_PARAM;

typedef struct _BISETSTATUSBACKFUNCTIONEX2_PARAM
{
	int nHandle;
	StatusCB_t fnStatusBack;
	LPVOID lpParam;
} BISETSTATUSBACKFUNCTIONEX2_PARAM;

typedef struct _BICANCELSTATUSBACK_PARAM
{
	int nHandle;
} BICANCELSTATUSBACK_PARAM;

typedef struct _BIRESETPRINTER_PARAM
{
	int nHandle;
} BIRESETPRINTER_PARAM;

typedef struct _BIGETCOUNTER_PARAM
{
	int nHandle;
	WORD wCounter;
	DWORD dwReadCounter;
} BIGETCOUNTER_PARAM;

typedef struct _BIRESETCOUNTER_PARAM
{
	int nHandle;
	WORD wCounter;
} BIRESETCOUNTER_PARAM;

typedef struct _BIDIRECTIOEX_PARAM
{
	int nHandle;
	DWORD dwWriteLen;
	BYTE abyWriteCmd[128];
	DWORD dwReadLen;
	BYTE abyReadCmd[128];
	DWORD dwTimeout;
	BOOL bNullTerminate;
	BYTE byOption;
} BIDIRECTIOEX_PARAM;

typedef struct _BIOPENDRAWER_PARAM
{
	int nHandle;
	BYTE drawer;
	BYTE pulse;
} BIOPENDRAWER_PARAM;

typedef struct _BISCNCLAMPPAPER_PARAM
{
	int nHandle;
} BISCNCLAMPPAPER_PARAM;

typedef struct _BIFORCERESETPRINTER_PARAM
{
	int nHandle;
} BIFORCERESETPRINTER_PARAM;

typedef struct _BIGETEXTENDSTATUS_PARAM
{
	int nHandle;
	WORD wStatus;
} BIGETEXTENDSTATUS_PARAM;

typedef struct _PRINTLINE_PARAM
{
	int nHandle;
	DWORD dwLength;
	char achText[1024];
} PRINTLINE_PARAM;

typedef struct _PRINTFILE_PARAM
{
	int nHandle;
	char achFile[1024];
	long lSize;
} PRINTFILE_PARAM;

typedef struct _STATUSAPI_PARAM
{
	COMMAND eCommand;
	int nStatusAPIResult;
	pthread_t nThreadId;
	union
	{
		BIOPENMONPRINTER_PARAM stBiOpenMonPrinter;
		BICLOSEMONPRINTER_PARAM stBiCloseMonPrinter;
		BILOCKPRINTER_PARAM stBiLockPrinter;
		BIUNLOCKPRINTER_PARAM stBiUnlockPrinter;
		BIDIRECTIOEX_PARAM stBiDirectIOEx;
		BIRESETPRINTER_PARAM stBiResetPrinter;
		BIGETSTATUS_PARAM stBiGetStatus;
		BISETSTATUSBACKFUNCTIONEX2_PARAM stBiSetStatusBackFunctionEx2;
		BICANCELSTATUSBACK_PARAM stBiCancelStatusBack;
		BIGETCOUNTER_PARAM stBiGetCounter;
		BIRESETCOUNTER_PARAM stBiResetCounter;
		BIOPENDRAWER_PARAM stBiOpenDrawer;
		BISCNCLAMPPAPER_PARAM stBiSCNClampPaper;
		BIFORCERESETPRINTER_PARAM stBiForceResetPrinter;
		BIGETEXTENDSTATUS_PARAM stBiGetExtendStatus;
		PRINTLINE_PARAM stPrintLine;
		PRINTFILE_PARAM stPrintFile;
		int nHandle;
	} stParam;
} STATUSAPI_PARAM;

typedef struct _COMMAND_MENU
{
	COMMAND eCommand;
	const char* strDescription;
} COMMAND_MENU;

static const COMMAND_MENU f_astCommandMenu[] =
{
	{QUIT, "Quit"},
	{BIOPENMONPRINTER, "BiOpenMonPrinter"},
	{BICLOSEMONPRINTER, "BiCloseMonPrinter"},
	{BILOCKPRINTER, "BiLockPrinter"},
	{BIUNLOCKPRINTER, "BiUnlockPrinter"},
	{BIDIRECTIOEX, "BiDirectIOEx"},
	{BIRESETPRINTER, "BiResetPrinter"},
	{BIGETSTATUS, "BiGetStatus"},
	{BISETSTATUSBACKFUNCTIONEX2, "BiSetStatusBackFunctionEx2"},
	{BICANCELSTATUSBACK, "BiCancelStatusBack"},
	{BIGETCOUNTER, "BiGetCounter"},
	{BIRESETCOUNTER, "BiResetCounter"},
	{BIOPENDRAWER, "BiOpenDrawer"},
	{BISCNCLAMPPAPER, "BiSCNClampPaper"},
	{BIFORCERESETPRINTER, "BiForceResetPrinter"},
	{BIGETEXTENDSTATUS, "BiGetExtendStatus"},
	{PRINTLINE, "PrintLine"},
	{PRINTFILE, "PrintFile"},
};

static CStatusAPI f_oStatusAPI;

static struct _Printers {
		int	nHandle;
		int Type;
		char* Name;
} g_Printers[64] = {{0}};

int CALLBACK UpdateStatus(DWORD dwStatus, LPVOID pvParam)
{
	struct _Printers* pp = (struct _Printers*)pvParam;
	printf("\nUpdateStatus(ASB=%.8X, Handle=%d, Name=%s)\n",
		  dwStatus, pp ? pp->nHandle : 0, pp ? pp->Name : "<Unknown>");
	return 0;
}

void	ShowCommands()
{
	size_t nCommandIndex;
	size_t nCommandSize;

	nCommandSize = sizeof(f_astCommandMenu) / sizeof(f_astCommandMenu[0]);

	for(nCommandIndex = 0; nCommandIndex < nCommandSize; nCommandIndex++)
	{
		printf("[%d] %s\n", f_astCommandMenu[nCommandIndex].eCommand, f_astCommandMenu[nCommandIndex].strDescription);
	}
}

void	ShowPrinters()
{
	size_t n, nSize;
	puts("-- Printer handle list --");
	for(n = 0, nSize = sizeof(g_Printers)/sizeof(g_Printers[0]); n < nSize; n++)
	{
		if (g_Printers[n].nHandle) {
			printf("%3d = %s (%s)\n", g_Printers[n].nHandle, g_Printers[n].Name,
								g_Printers[n].Type == 1 ? "Port" : "Printer");
		}
	}
	puts("-- End of list --");
}

int	GetPrinterIdx(int nHandle)
{
	int n, nx;
	for(n = 0, nx = sizeof(g_Printers)/sizeof(g_Printers[0]); n < nx; n++)
	{
		if (g_Printers[n].nHandle == nHandle && nHandle > 0) {
			return n;
		}
	}
	return -1;
}

const char* GetCommandDescription(COMMAND eCommand)
{
	const char* strDescription;
	size_t nCommandIndex;
	size_t nCommandSize;

	strDescription = NULL;

	nCommandSize = sizeof(f_astCommandMenu) / sizeof(f_astCommandMenu[0]);

	for(nCommandIndex = 0; nCommandIndex < nCommandSize; nCommandIndex++)
	{
		if(f_astCommandMenu[nCommandIndex].eCommand == eCommand)
		{
			strDescription = f_astCommandMenu[nCommandIndex].strDescription;
			break;
		}
	}

	return strDescription;
}

bool	IsValidCommand(COMMAND eCommand)
{
	bool bIsValidCommand;
	size_t nCommandIndex;
	size_t nCommandSize;

	nCommandSize = sizeof(f_astCommandMenu) / sizeof(f_astCommandMenu[0]);

	for(nCommandIndex = 0; nCommandIndex < nCommandSize; nCommandIndex++)
	{
		if(f_astCommandMenu[nCommandIndex].eCommand == eCommand)
		{
			break;
		}
	}

	bIsValidCommand = (nCommandIndex < nCommandSize);

	return bIsValidCommand;
}

COMMAND	SelectCommand()
{
	COMMAND eCommand;
	bool bIsValidCommand;

	do
	{
		puts("");
		ShowCommands();

		do printf("Select Command: ");
		while (1 != scanf("%d", (int*)&eCommand) && scanf("%*s"));
		bIsValidCommand = IsValidCommand(eCommand);
	} while(!bIsValidCommand);

	return eCommand;
}

void LoadStatusAPILibrary()
{
	bool bIsLoaded;
	bIsLoaded = f_oStatusAPI.Load();
	if(bIsLoaded)
	{
		printf("%s is loaded successfully.\n", STATUSAPI_NAME);
	}
	else
	{
		printf("%s is not loaded successfully!!!\n", STATUSAPI_NAME);
	}
}

void UnloadStatusAPILibrary()
{
	if(f_oStatusAPI.IsLoaded())
	{
		f_oStatusAPI.UnLoad();
		printf("%s is unloaded successfully.\n", STATUSAPI_NAME);
	}
	else
	{
		printf("%s is not unloaded successfully!!!\n", STATUSAPI_NAME);
	}
}

void ConvertStringToBytes(char* strString, BYTE* pbyBytes, size_t nBytesSize )
{
	size_t nBytesIndex;
	char* pstrToken;

	nBytesIndex = 0;

	pstrToken = strtok(strString, " \n\r");

	while((pstrToken != NULL) && (nBytesIndex < nBytesSize))
	{
		pbyBytes[nBytesIndex] = strtol(pstrToken, NULL, 16);
		pstrToken = strtok(NULL, " \n\r");
		nBytesIndex++;
	}
}

void ConvertBytesToString(BYTE* pbyBytes, size_t nBytesSize, char* strString)
{
	size_t nBytesIndex;
	unsigned int nNumber;
	char* pstrCurLoc;

	static const BYTE ffx4[] = {0xff, 0xff, 0xff, 0xff};	// Null pointer magic data
	if (0 == memcmp(pbyBytes, ffx4, sizeof(ffx4))) {
		strcpy(strString, "(null)");
		return;
	}

	pstrCurLoc = strString;

	for (nBytesIndex = 0; nBytesIndex < nBytesSize; nBytesIndex++)
	{
		nNumber = pbyBytes[nBytesIndex];
		sprintf(pstrCurLoc, "%.2X ", nNumber);
		pstrCurLoc += 3;
	}

	*pstrCurLoc = '\0';
}

LPBYTE CheckNull(LPBYTE pb)
{
	const static BYTE ffx4[] = {0xff, 0xff, 0xff, 0xff};
	// return NULL if !pb or *pb={0xff, 0xff, 0xff, 0xff}
	return pb && memcmp(pb, ffx4, sizeof(ffx4)) ? pb : NULL;
}

char* CheckNull(char* psz)
{
	// convert '""' -> null string ''
	if (psz && 0 == strncasecmp(psz, "\"\"", sizeof("\"\""))) {
		*psz = 0;
	}
	// return NULL if !psz or *psz="null" (case ignored)
	return psz && strncasecmp(psz, "null", sizeof("null")) ? psz : NULL;
}

void BiOpenMonPrinterParam(BIOPENMONPRINTER_PARAM* pstParam)
{
	puts("BiOpenMonPrinter Parameters:");
	do printf("Type (1=Port,2=Printer): ");
	while (1 != scanf("%d", &pstParam->nType) && scanf("%*s"));
	puts("Note: \"\"=Null string, null=Null pointer");
	do printf("Name: ");
	while (1 != scanf("%s", pstParam->strName) && scanf("%*s"));
}

void BiCloseMonPrinterParam(BICLOSEMONPRINTER_PARAM* pstParam)
{
	puts("BiCloseMonPrinter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiLockPrinterParam(BILOCKPRINTER_PARAM* pstParam)
{
	puts("BiLockPrinter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	do printf("Timeout: ");
	while (1 != scanf("%u", &pstParam->dwTimeout) && scanf("%*s"));
}

void BiUnlockPrinterParam(BIUNLOCKPRINTER_PARAM* pstParam)
{
	puts("BiUnlockPrinter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiDirectIOExParam(BIDIRECTIOEX_PARAM* pstParam)
{
	char strSequence[128];
	puts("BiDirectIOEx Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	do printf("Write command length: ");
	while (1 != scanf("%u", &pstParam->dwWriteLen) && scanf("%*s"));
	getchar();
	puts("Note: \"ff ff ff ff\"=Null pointer");
	do printf("Write command sequence in hex format: ");
	while (NULL == fgets(strSequence, sizeof(strSequence), stdin) && scanf("%*s"));
	ConvertStringToBytes(strSequence, pstParam->abyWriteCmd, pstParam->dwWriteLen);
	do printf("Timeout: ");
	while (1 != scanf("%u", &pstParam->dwTimeout) && scanf("%*s"));
	do printf("Null Terminate ? (0=No/1=Yes): ");
	while (1 != scanf("%d", &pstParam->bNullTerminate) && scanf("%*s"));
	if (pstParam->bNullTerminate > 0) {
		pstParam->dwReadLen = sizeof(pstParam->abyReadCmd);
	}
	else {
		do printf("Read length (-1,65535=Null pointer): ");
		while ((1 != scanf("%d", (int*)&pstParam->dwReadLen) && scanf("%*s")) ||
			  (pstParam->dwReadLen > sizeof(pstParam->abyReadCmd) && 0xffff != (WORD)pstParam->dwReadLen));
		if (0xffff == (WORD)pstParam->dwReadLen) {
			memset(pstParam->abyReadCmd, 0xff, 4);
		}
	}
	unsigned ui;
	do printf("Option (0=NoASB): ");
	while (1 != scanf("%u", &ui) && scanf("%*s"));
	pstParam->byOption = (BYTE)ui;
}

void BiResetPrinterParam(BIRESETPRINTER_PARAM* pstParam)
{
	puts("BiResetPrinter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiGetStatusParam(BIGETSTATUS_PARAM* pstParam)
{
	puts("BiGetStatus Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiSetStatusBackFunctionEx2Param(BISETSTATUSBACKFUNCTIONEX2_PARAM* pstParam)
{
	puts("BiSetStatusBackFunctionEx2 Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	pstParam->fnStatusBack = UpdateStatus;
	int n = GetPrinterIdx(pstParam->nHandle);
	pstParam->lpParam = n >= 0 ? (LPVOID)&g_Printers[n] : NULL;
}

void BiCancelStatusBackParam(BICANCELSTATUSBACK_PARAM* pstParam)
{
	puts("BiCancelStatusBack Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiGetCounterParam(BIGETCOUNTER_PARAM* pstParam)
{
	puts("BiGetCounter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	unsigned ui;
	do printf("Counter number: ");
	while (1 != scanf("%u", &ui) && scanf("%*s"));
	pstParam->wCounter = (WORD)ui;
}

void BiResetCounterParam(BIRESETCOUNTER_PARAM* pstParam)
{
	puts("BiResetCounter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	unsigned ui;
	do printf("Counter number: ");
	while (1 != scanf("%u", &ui) && scanf("%*s"));
	pstParam->wCounter = (WORD)ui;
}

void BiOpenDrawerParam(BIOPENDRAWER_PARAM* pstParam)
{
	puts("BiOpenDrawer Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	unsigned ui;
	do printf("drawer (1, 2): ");
	while (1 != scanf("%u", &ui) && scanf("%*s"));
	pstParam->drawer = (BYTE)ui;
	do printf("pulse (1, 2, ..., 8): ");
	while (1 != scanf("%u", &ui) && scanf("%*s"));
	pstParam->pulse = (BYTE)ui;
}

void BiSCNClampPaperParam(BISCNCLAMPPAPER_PARAM* pstParam)
{
	puts("BiSCNClampPaper Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiForceResetPrinterParam(BIFORCERESETPRINTER_PARAM* pstParam)
{
	puts("BiForceResetPrinter Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void BiGetExtendStatusParam(BIGETEXTENDSTATUS_PARAM* pstParam)
{
	puts("BiGetExtendStatus Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
}

void PrintLineParam(PRINTLINE_PARAM* pstParam)
{
	char strSequence[1023];
	puts("PrintLine Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	getchar();
	do printf("Printing text: ");
	while (NULL == fgets(strSequence, sizeof(strSequence), stdin) && scanf("%*s"));
	strcpy(pstParam->achText, strSequence);
	pstParam->dwLength = strlen(pstParam->achText);
}

void PrintFileParam(PRINTFILE_PARAM* pstParam)
{
	char strbuf[1023];
	puts("PrintFile Parameters:");
	ShowPrinters();
	do printf("Printer handle: ");
	while ((1 != scanf("%d", &pstParam->nHandle) || pstParam->nHandle <= 0) && scanf("%*s"));
	getchar();
	int OK = 0;
	do {
		do printf("File name to print: ");
		while (NULL == fgets(strbuf, sizeof(strbuf), stdin) && scanf("%*s"));
		DWORD dwLen = strlen(strbuf);
		if (dwLen > 0) {
			strbuf[dwLen - 1] = 0;
		}
		FILE* fp = fopen(strbuf, "r");
		if (fp) {
			fseek(fp, 0, SEEK_END);
			pstParam->lSize = ftell(fp);
			fclose(fp);
			OK = 1;
		}
		else {
			printf("ERROR! %s not found!\n", strbuf);
		}
	} while (!OK);
	strcpy(pstParam->achFile, strbuf);
}

void SpecifyParameters(STATUSAPI_PARAM* pstParam)
{
	puts("");
	switch(pstParam->eCommand)
	{
		case BIOPENMONPRINTER:
			BiOpenMonPrinterParam(&pstParam->stParam.stBiOpenMonPrinter);
		break;
		case BICLOSEMONPRINTER:
			BiCloseMonPrinterParam(&pstParam->stParam.stBiCloseMonPrinter);
		break;
		case BILOCKPRINTER:
			BiLockPrinterParam(&pstParam->stParam.stBiLockPrinter);
		break;
		case BIUNLOCKPRINTER:
			BiUnlockPrinterParam(&pstParam->stParam.stBiUnlockPrinter);
		break;
		case BIDIRECTIOEX:
			BiDirectIOExParam(&pstParam->stParam.stBiDirectIOEx);
		break;
		case BIRESETPRINTER:
			BiResetPrinterParam(&pstParam->stParam.stBiResetPrinter);
		break;
		case BIGETSTATUS:
			BiGetStatusParam(&pstParam->stParam.stBiGetStatus);
		break;
		case BISETSTATUSBACKFUNCTIONEX2:
			BiSetStatusBackFunctionEx2Param(&pstParam->stParam.stBiSetStatusBackFunctionEx2);
		break;
		case BICANCELSTATUSBACK:
			BiCancelStatusBackParam(&pstParam->stParam.stBiCancelStatusBack);
		break;
		case BIGETCOUNTER:
			BiGetCounterParam(&pstParam->stParam.stBiGetCounter);
		break;
		case BIRESETCOUNTER:
			BiResetCounterParam(&pstParam->stParam.stBiResetCounter);
		break;
		case BIOPENDRAWER:
			BiOpenDrawerParam(&pstParam->stParam.stBiOpenDrawer);
		break;
		case BISCNCLAMPPAPER:
			BiSCNClampPaperParam(&pstParam->stParam.stBiSCNClampPaper);
		break;
		case BIFORCERESETPRINTER:
			BiForceResetPrinterParam(&pstParam->stParam.stBiForceResetPrinter);
		break;
		case BIGETEXTENDSTATUS:
			BiGetExtendStatusParam(&pstParam->stParam.stBiGetExtendStatus);
		break;
		case PRINTLINE:
			PrintLineParam(&pstParam->stParam.stPrintLine);
		break;
		case PRINTFILE:
			PrintFileParam(&pstParam->stParam.stPrintFile);
		break;
		default:
			puts("Invalid Command!!!");
		break;
	}
}

void ExecuteStatusAPI(STATUSAPI_PARAM* pstParam)
{
	pstParam->nThreadId = pthread_self();
	switch(pstParam->eCommand)
	{
		case BIOPENMONPRINTER:
		{
			BIOPENMONPRINTER_PARAM* pstBiOpenMonPrinter;
			pstBiOpenMonPrinter = &pstParam->stParam.stBiOpenMonPrinter;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiOpenMonPrinter(pstBiOpenMonPrinter->nType, CheckNull(pstBiOpenMonPrinter->strName));
			if (pstParam->nStatusAPIResult > 0) {
				int n, nx;
				for (n = 0, nx = sizeof(g_Printers)/sizeof(g_Printers[0]); n < nx; n++)
					if (g_Printers[n].nHandle == 0) break;
				if (n < nx) {
					g_Printers[n].nHandle = pstParam->nStatusAPIResult;
					g_Printers[n].Type = pstBiOpenMonPrinter->nType;
					g_Printers[n].Name = strdup(pstBiOpenMonPrinter->strName);
				}
				else
					puts("ERROR! No more space in global printer list.");
			}
		}
		break;
		case BICLOSEMONPRINTER:
		{
			BICLOSEMONPRINTER_PARAM* pstBiCloseMonPrinter;
			pstBiCloseMonPrinter = &pstParam->stParam.stBiCloseMonPrinter;
			pstParam->nStatusAPIResult = f_oStatusAPI.BiCloseMonPrinter(pstBiCloseMonPrinter->nHandle);
			if (0 == pstParam->nStatusAPIResult) {
				int n = GetPrinterIdx(pstBiCloseMonPrinter->nHandle);
				if (n >= 0) {
					g_Printers[n].nHandle = 0;
					free(g_Printers[n].Name);
					g_Printers[n].Name = NULL;
					g_Printers[n].Type = 0;
				}
			}
		}
		break;
		case BILOCKPRINTER:
		{
			BILOCKPRINTER_PARAM* pstBiLockPrinter;
			pstBiLockPrinter = &pstParam->stParam.stBiLockPrinter;
			pstParam->nStatusAPIResult = f_oStatusAPI.BiLockPrinter(pstBiLockPrinter->nHandle, pstBiLockPrinter->dwTimeout);
		}
		break;
		case BIUNLOCKPRINTER:
		{
			BIUNLOCKPRINTER_PARAM* pstBiUnlockPrinter;
			pstBiUnlockPrinter = &pstParam->stParam.stBiUnlockPrinter;
			pstParam->nStatusAPIResult = f_oStatusAPI.BiUnlockPrinter(pstBiUnlockPrinter->nHandle);
		}
		break;
		case BIDIRECTIOEX:
		{
			BIDIRECTIOEX_PARAM* pstBiDirectIOEx;
			pstBiDirectIOEx = &pstParam->stParam.stBiDirectIOEx;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiDirectIOEx(pstBiDirectIOEx->nHandle, 
				pstBiDirectIOEx->dwWriteLen, CheckNull(pstBiDirectIOEx->abyWriteCmd),
				&pstBiDirectIOEx->dwReadLen, CheckNull(pstBiDirectIOEx->abyReadCmd),
				pstBiDirectIOEx->dwTimeout, pstBiDirectIOEx->bNullTerminate, pstBiDirectIOEx->byOption);
		}
		break;
		case BIRESETPRINTER:
		{
			BIRESETPRINTER_PARAM* pstBiResetPrinter;
			pstBiResetPrinter = &pstParam->stParam.stBiResetPrinter;
			pstParam->nStatusAPIResult = f_oStatusAPI.BiResetPrinter(pstBiResetPrinter->nHandle);
		}
		break;
		case BIGETSTATUS:
		{
			BIGETSTATUS_PARAM* pstBiGetStatus;
			pstBiGetStatus = &pstParam->stParam.stBiGetStatus;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiGetStatus(pstBiGetStatus->nHandle, &pstBiGetStatus->dwStatus);
		}
		break;
		case BISETSTATUSBACKFUNCTIONEX2:
		{
			BISETSTATUSBACKFUNCTIONEX2_PARAM* pstBiSetStatusBackFunctionEx2;
			pstBiSetStatusBackFunctionEx2 = &pstParam->stParam.stBiSetStatusBackFunctionEx2;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiSetStatusBackFunctionEx2(pstBiSetStatusBackFunctionEx2->nHandle,
				pstBiSetStatusBackFunctionEx2->fnStatusBack, pstBiSetStatusBackFunctionEx2->lpParam);
		}
		break;
		case BICANCELSTATUSBACK:
		{
			BICANCELSTATUSBACK_PARAM* pstBiCancelStatusBack;
			pstBiCancelStatusBack = &pstParam->stParam.stBiCancelStatusBack;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiCancelStatusBack(pstBiCancelStatusBack->nHandle);
		}
		break;
		case BIGETCOUNTER:
		{
			BIGETCOUNTER_PARAM* pstBiGetCounter;
			pstBiGetCounter = &pstParam->stParam.stBiGetCounter;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiGetCounter(pstBiGetCounter->nHandle, pstBiGetCounter->wCounter, &pstBiGetCounter->dwReadCounter);
		}
		break;
		case BIRESETCOUNTER:
		{
			BIRESETCOUNTER_PARAM* pstBiResetCounter;
			pstBiResetCounter = &pstParam->stParam.stBiResetCounter;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiResetCounter(pstBiResetCounter->nHandle, pstBiResetCounter->wCounter);
		}
		break;
		case BIOPENDRAWER:
			BIOPENDRAWER_PARAM* pstBiOpenDrawer;
			pstBiOpenDrawer = &pstParam->stParam.stBiOpenDrawer;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiOpenDrawer(pstBiOpenDrawer->nHandle, pstBiOpenDrawer->drawer, pstBiOpenDrawer->pulse);
		break;
		case BISCNCLAMPPAPER:
			BISCNCLAMPPAPER_PARAM* pstBiSCNClampPaper;
			pstBiSCNClampPaper = &pstParam->stParam.stBiSCNClampPaper;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiSCNClampPaper(pstBiSCNClampPaper->nHandle);
		break;
		case BIFORCERESETPRINTER:
			BIFORCERESETPRINTER_PARAM* pstBiForceResetPrinter;
			pstBiForceResetPrinter = &pstParam->stParam.stBiForceResetPrinter;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiForceResetPrinter(pstBiForceResetPrinter->nHandle);
		break;
		case BIGETEXTENDSTATUS:
			BIGETEXTENDSTATUS_PARAM* pstBiGetExtendStatus;
			pstBiGetExtendStatus = &pstParam->stParam.stBiGetExtendStatus;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiGetExtendStatus(pstBiGetExtendStatus->nHandle, &pstBiGetExtendStatus->wStatus);
		break;
		case PRINTLINE:
		{
			PRINTLINE_PARAM* pstPrintLine;
			pstPrintLine = &pstParam->stParam.stPrintLine;
			DWORD dw = 0;
			pstParam->nStatusAPIResult =
				f_oStatusAPI.BiDirectIOEx(pstPrintLine->nHandle, pstPrintLine->dwLength,
				(LPBYTE)pstPrintLine->achText, &dw, NULL, 500, 0, 0);
		}
		break;
		case PRINTFILE:
		{
			PRINTFILE_PARAM* pstPrintFile;
			pstPrintFile = &pstParam->stParam.stPrintFile;
			DWORD dwWrite = 0, dwRead = 0;
			BYTE buf[4096];
			FILE* fp = fopen(pstPrintFile->achFile, "r");
			fseek(fp, 0, SEEK_SET);
			long lSize = pstPrintFile->lSize;
			do {
				dwWrite = fread(buf, sizeof(buf[0]), sizeof(buf), fp);
				pstParam->nStatusAPIResult =
					f_oStatusAPI.BiDirectIOEx(pstPrintFile->nHandle, dwWrite,
					buf, &dwRead, NULL, 30000, 0, 0);
				if (0 == pstParam->nStatusAPIResult)
					lSize -= dwWrite;
			} while (pstParam->nStatusAPIResult == 0 && lSize > 0);
			fclose(fp);
		}
		break;
		default:
			puts("Invalid Command!!!");
		break;
	}
}

void	PrintResult(STATUSAPI_PARAM* pstParam)
{
	switch(pstParam->eCommand)
	{
		case BIOPENMONPRINTER:
		{
			BIOPENMONPRINTER_PARAM* pstBiOpenMonPrinter;
			pstBiOpenMonPrinter = &pstParam->stParam.stBiOpenMonPrinter;
			printf("%.8X:%.8X(%d) = BiOpenMonPrinter(%d, %s)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiOpenMonPrinter->nType, CheckNull(pstBiOpenMonPrinter->strName));
		}
		break;
		case BICLOSEMONPRINTER:
		{
			BICLOSEMONPRINTER_PARAM* pstBiCloseMonPrinter;
			pstBiCloseMonPrinter = &pstParam->stParam.stBiCloseMonPrinter;
			printf("%.8X:%.8X(%d) = BiCloseMonPrinter(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiCloseMonPrinter->nHandle);
		}
		break;
		case BILOCKPRINTER:
		{
			BILOCKPRINTER_PARAM* pstBiLockPrinter;
			pstBiLockPrinter = &pstParam->stParam.stBiLockPrinter;
			printf("%.8X:%.8X(%d) = BiLockPrinter(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiLockPrinter->nHandle);
		}
		break;
		case BIUNLOCKPRINTER:
		{
			BIUNLOCKPRINTER_PARAM* pstBiUnlockPrinter;
			pstBiUnlockPrinter = &pstParam->stParam.stBiUnlockPrinter;
			printf("%.8X:%.8X(%d) = BiUnlockPrinter(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiUnlockPrinter->nHandle);
		}
		break;
		case BIDIRECTIOEX:
		{
			char strWriteData[128*3 + 2];
			char strReadData[128*3 + 2];
			BIDIRECTIOEX_PARAM* pstBiDirectIOEx;
			pstBiDirectIOEx = &pstParam->stParam.stBiDirectIOEx;
 			ConvertBytesToString(pstBiDirectIOEx->abyWriteCmd, pstBiDirectIOEx->dwWriteLen, strWriteData);
			ConvertBytesToString(pstBiDirectIOEx->abyReadCmd, pstBiDirectIOEx->dwReadLen, strReadData);
			printf("%.8X:%.8X(%d) = BiDirectIOEx(%d, %u, %s, %u, %s, %u, %s, %u)\n",  (DWORD)pstParam->nThreadId,
				pstParam->nStatusAPIResult,  pstParam->nStatusAPIResult, pstBiDirectIOEx->nHandle,
				pstBiDirectIOEx->dwWriteLen, strWriteData,
				pstBiDirectIOEx->dwReadLen,	strReadData, pstBiDirectIOEx->dwTimeout,
				pstBiDirectIOEx->bNullTerminate ? "TRUE" : "FALSE",	pstBiDirectIOEx->byOption);
		}
		break;
		case BIRESETPRINTER:
		{
			BIRESETPRINTER_PARAM* pstBiResetPrinter;
			pstBiResetPrinter = &pstParam->stParam.stBiResetPrinter;
			printf("%.8X:%.8X(%d) = BiResetPrinter(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiResetPrinter->nHandle);
		}
		break;
		case BIGETSTATUS:
		{
			BIGETSTATUS_PARAM* pstBiGetStatus;
			pstBiGetStatus = &pstParam->stParam.stBiGetStatus;
			printf("%.8X:%.8X(%d) = BiGetStatus(%d, %.8X)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiGetStatus->nHandle, pstBiGetStatus->dwStatus);
		}
		break;
		case BISETSTATUSBACKFUNCTIONEX2:
		{
			BISETSTATUSBACKFUNCTIONEX2_PARAM* pstBiSetStatusBackFunctionEx2;
			pstBiSetStatusBackFunctionEx2 = &pstParam->stParam.stBiSetStatusBackFunctionEx2;
			printf("%.8X:%.8X(%d) = BiSetStatusBackFunctionEx2(%d, %p, %p)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiSetStatusBackFunctionEx2->nHandle, pstBiSetStatusBackFunctionEx2->fnStatusBack, pstBiSetStatusBackFunctionEx2->lpParam);
		}
		break;
		case BICANCELSTATUSBACK:
		{
			BICANCELSTATUSBACK_PARAM* pstBiCancelStatusBack;
			pstBiCancelStatusBack = &pstParam->stParam.stBiCancelStatusBack;
			printf("%.8X:%.8X(%d) = BiCancelStatusBack(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiCancelStatusBack->nHandle);
		}
		break;
		case BIGETCOUNTER:
		{
			BIGETCOUNTER_PARAM* pstBiGetCounter;
			pstBiGetCounter = &pstParam->stParam.stBiGetCounter;
			printf("%.8X:%.8X(%d) = BiGetCounter(%d, %u, %u)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiGetCounter->nHandle, pstBiGetCounter->wCounter, pstBiGetCounter->dwReadCounter);
		}
		break;
		case BIRESETCOUNTER:
		{
			BIRESETCOUNTER_PARAM* pstBiResetCounter;
			pstBiResetCounter = &pstParam->stParam.stBiResetCounter;
			printf("%.8X:%.8X(%d) = BiResetCounter(%d, %u)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiResetCounter->nHandle, pstBiResetCounter->wCounter);
		}
		break;
		case BIOPENDRAWER:
		{
			BIOPENDRAWER_PARAM* pstBiOpenDrawer;
			pstBiOpenDrawer = &pstParam->stParam.stBiOpenDrawer;
			printf("%.8X:%.8X(%d) = BiOpenDrawer(%d, %d, %d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiOpenDrawer->nHandle, pstBiOpenDrawer->drawer, pstBiOpenDrawer->pulse);
		}
		break;
		case BISCNCLAMPPAPER:
		{
			BISCNCLAMPPAPER_PARAM* pstBiSCNClampPaper;
			pstBiSCNClampPaper = &pstParam->stParam.stBiSCNClampPaper;
			printf("%.8X:%.8X(%d) = BiSCNClampPaper(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiSCNClampPaper->nHandle);			
		}
		break;
		case BIFORCERESETPRINTER:
		{
			BIFORCERESETPRINTER_PARAM* pstBiForceResetPrinter;
			pstBiForceResetPrinter = &pstParam->stParam.stBiForceResetPrinter;
			printf("%.8X:%.8X(%d) = BiForceResetPrinter(%d)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiForceResetPrinter->nHandle);			
		}
		break;
		case BIGETEXTENDSTATUS:
		{
			BIGETEXTENDSTATUS_PARAM* pstBiGetExtendStatus;
			pstBiGetExtendStatus = &pstParam->stParam.stBiGetExtendStatus;
			printf("%.8X:%.8X(%d) = BiGetExtendStatus(%d, %.4X)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstBiGetExtendStatus->nHandle, pstBiGetExtendStatus->wStatus);
		}
		break;
		case PRINTLINE:
		{
			PRINTLINE_PARAM* pstPrintLine;
			pstPrintLine = &pstParam->stParam.stPrintLine;
			if (pstPrintLine->dwLength) {
				pstPrintLine->achText[pstPrintLine->dwLength - 1] = 0;
				pstPrintLine->dwLength--;
			}
			printf("%.8X:%.8X(%d) = PrintLine(%d, %d, %s)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstPrintLine->nHandle, pstPrintLine->dwLength, pstPrintLine->achText);
		}
		break;
		case PRINTFILE:
		{
			PRINTFILE_PARAM* pstPrintFile;
			pstPrintFile = &pstParam->stParam.stPrintFile;
			printf("%.8X:%.8X(%d) = PrintFile(%d, %s, %ld)\n", (DWORD)pstParam->nThreadId, pstParam->nStatusAPIResult, pstParam->nStatusAPIResult,
				pstPrintFile->nHandle, pstPrintFile->achFile, pstPrintFile->lSize);
		}
		break;
		default:
			puts("Invalid Command!!!");
		break;
	}
}

void* ExecuteStatusAPIProc(void* pUserParam)
{
	STATUSAPI_PARAM* pstParam;
	pstParam = (STATUSAPI_PARAM*)pUserParam;
	ExecuteStatusAPI(pstParam);
	return NULL;
}

int myGetch()
{
	struct termios oldTerm, newTerm;
	int ch;

	tcgetattr( STDIN_FILENO, &oldTerm );
	newTerm = oldTerm;
	newTerm.c_lflag &= ~( ICANON | ECHO );
	tcsetattr( STDIN_FILENO, TCSANOW, &newTerm );

	do {
		ch = getchar();
	} while('\n' == ch);

	tcsetattr( STDIN_FILENO, TCSANOW, &oldTerm );

	return ch;
}

int main()
{
	STATUSAPI_PARAM stParam1;
	STATUSAPI_PARAM stParam2;
	BOOL bExecute2APIs;
	pthread_t hThread;

	LoadStatusAPILibrary();

	if(f_oStatusAPI.IsLoaded())
	{
		while(true)
		{
			do printf("\nDo you want to execute 2 APIs concurrently? (0=No/1=Yes): ");
			while ((1 != scanf("%d", &bExecute2APIs) && scanf("%*s")) || (bExecute2APIs & 0xfffffffe));

			if(bExecute2APIs)
			{
				puts("\nSelect API to be executed first:");
			}
			else
			{
				puts("\nSelect API to be executed:");
			}

			memset(&stParam1, 0, sizeof(stParam1));
			stParam1.eCommand = SelectCommand();

			if(QUIT == stParam1.eCommand)
			{
				break;
			}
			else
			{
				SpecifyParameters(&stParam1);
			}

			if(bExecute2APIs)
			{
				puts("\nSelect API to be executed while executing the first API:");
				memset(&stParam2, 0, sizeof(stParam2));
				stParam2.eCommand = SelectCommand();

				if(QUIT == stParam2.eCommand)
				{
					break;
				}
				else
				{
					SpecifyParameters(&stParam2);
				}
				pthread_create(&hThread, NULL, ExecuteStatusAPIProc, &stParam1);

				printf("Currently executing %s...\n", GetCommandDescription(stParam1.eCommand));
				printf("Press any key except enter to start executing %s...\n", GetCommandDescription(stParam2.eCommand));
				myGetch();

				ExecuteStatusAPI(&stParam2);
				pthread_join(hThread, NULL);

				PrintResult(&stParam1);
				PrintResult(&stParam2);
			}
			else
			{
				ExecuteStatusAPI(&stParam1);
				PrintResult(&stParam1);
			}
		}

		// clean up
		int n, nx;
		for (n = 0, nx = sizeof(g_Printers)/sizeof(g_Printers[0]); n < nx; n++) {
			if (g_Printers[n].nHandle) {
				f_oStatusAPI.BiCloseMonPrinter(g_Printers[n].nHandle);
				g_Printers[n].nHandle = 0;
			}
			if (g_Printers[n].Name) {
				free(g_Printers[n].Name);
				g_Printers[n].Name = NULL;
			}
		}

		UnloadStatusAPILibrary();
	}

    return 0;
}
