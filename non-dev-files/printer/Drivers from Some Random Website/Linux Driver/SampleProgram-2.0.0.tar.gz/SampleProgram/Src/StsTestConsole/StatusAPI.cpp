#include "StatusAPI.h"

#include <stdlib.h>

CStatusAPI::CStatusAPI(bool bLoadLibrary)
{
	if(bLoadLibrary)
	{
		Load();
	}
}

CStatusAPI::~CStatusAPI()
{
	if(IsLoaded())
	{
		UnLoad();
	}
}

bool CStatusAPI::Load()
{
	bool bIsLoaded;
	bIsLoaded = m_oDynLib.Load(STATUSAPI_NAME);
	if(bIsLoaded)
	{
		// Load the necessary functions for this application
		m_funcBiOpenMonPrinter
			= (BiOpenMonPrinter_t)m_oDynLib.GetSymbol("BiOpenMonPrinter");
		m_funcBiCloseMonPrinter
			= (BiCloseMonPrinter_t)m_oDynLib.GetSymbol("BiCloseMonPrinter");
		m_funcBiLockPrinter
			= (BiLockPrinter_t)m_oDynLib.GetSymbol("BiLockPrinter");
		m_funcBiUnlockPrinter
			= (BiUnlockPrinter_t)m_oDynLib.GetSymbol("BiUnlockPrinter");
		m_funcBiDirectIOEx
			= (BiDirectIOEx_t)m_oDynLib.GetSymbol("BiDirectIOEx");
		m_funcBiResetPrinter
			= (BiResetPrinter_t)m_oDynLib.GetSymbol("BiResetPrinter");
		m_funcBiGetStatus
			= (BiGetStatus_t)m_oDynLib.GetSymbol("BiGetStatus");
		m_funcBiSetStatusBackFunctionEx2
			= (BiSetStatusBackFunctionEx2_t)m_oDynLib.GetSymbol("BiSetStatusBackFunctionEx2");
		m_funcBiCancelStatusBack
			= (BiCancelStatusBack_t)m_oDynLib.GetSymbol("BiCancelStatusBack");
		m_funcBiGetCounter
			= (BiGetCounter_t)m_oDynLib.GetSymbol("BiGetCounter");
		m_funcBiResetCounter
			= (BiResetCounter_t)m_oDynLib.GetSymbol("BiResetCounter");
		m_funcBiOpenDrawer
			= (BiOpenDrawer_t)m_oDynLib.GetSymbol("BiOpenDrawer");
		m_funcBiSCNClampPaper
			= (BiSCNClampPaper_t)m_oDynLib.GetSymbol("BiSCNClampPaper");
		m_funcBiForceResetPrinter
			= (BiForceResetPrinter_t)m_oDynLib.GetSymbol("BiForceResetPrinter");
		m_funcBiGetExtendStatus
			= (BiGetExtendStatus_t)m_oDynLib.GetSymbol("BiGetExtendStatus");

		if ((NULL == m_funcBiOpenMonPrinter) ||
			(NULL == m_funcBiCloseMonPrinter) ||
			(NULL == m_funcBiLockPrinter) ||
			(NULL == m_funcBiUnlockPrinter) ||
			(NULL == m_funcBiDirectIOEx) ||
			(NULL == m_funcBiResetPrinter) ||
			(NULL == m_funcBiGetStatus) ||
			(NULL == m_funcBiSetStatusBackFunctionEx2) ||
			(NULL == m_funcBiCancelStatusBack) ||
			(NULL == m_funcBiGetCounter) ||
			(NULL == m_funcBiResetCounter) ||
			(NULL == m_funcBiOpenDrawer) ||
			(NULL == m_funcBiSCNClampPaper) ||
			(NULL == m_funcBiForceResetPrinter) ||
			(NULL == m_funcBiGetExtendStatus)) {
			UnLoad();
		}
	}
	return bIsLoaded;
}

bool CStatusAPI::UnLoad()
{
	return m_oDynLib.UnLoad();
}

bool CStatusAPI::IsLoaded()
{
	return m_oDynLib.IsLoaded();
}

int		CStatusAPI::BiOpenMonPrinter(int nType, LPSTR pName) {
	if (  m_funcBiOpenMonPrinter!=NULL ) {
		return m_funcBiOpenMonPrinter(nType, pName);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiCloseMonPrinter(int nHandle)
{
	if (  m_funcBiCloseMonPrinter!=NULL  ) {
		return m_funcBiCloseMonPrinter(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiLockPrinter(int nHandle, DWORD timeout)
{
	if (  m_funcBiLockPrinter != NULL )
	{
		return m_funcBiLockPrinter(nHandle, timeout);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiUnlockPrinter(int nHandle)
{
	if ( m_funcBiUnlockPrinter != NULL  )
	{
		return m_funcBiUnlockPrinter(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiDirectIOEx(int nHandle, DWORD writeLen, LPBYTE writeCmd, LPDWORD readLen, LPBYTE readBuff,
								 DWORD timeout,BOOL nullTerminate, BYTE option)
{
	if ( m_funcBiDirectIOEx != NULL  )
	{
		return m_funcBiDirectIOEx(nHandle, writeLen, writeCmd, readLen, readBuff,
									timeout, nullTerminate, option);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiResetPrinter(int nHandle)
{
	if (  m_funcBiResetPrinter != NULL  ) {
		return m_funcBiResetPrinter(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiGetStatus(int nHandle, LPDWORD lpStatus)
{
	if (  m_funcBiGetStatus!=NULL  ) {
		return m_funcBiGetStatus(nHandle, lpStatus);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiSetStatusBackFunctionEx2(int nHandle, StatusCB_t fnStatusBack, LPVOID lpParam)
{
	if (  m_funcBiSetStatusBackFunctionEx2 != NULL  ) {
		return m_funcBiSetStatusBackFunctionEx2 (nHandle, fnStatusBack, lpParam);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiCancelStatusBack(int nHandle)
{
	if (  m_funcBiCancelStatusBack != NULL  ) {
		return m_funcBiCancelStatusBack(nHandle);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiGetCounter(int nHandle, WORD readno, LPDWORD readcounter)
{
	if ( m_funcBiGetCounter != NULL  )
	{
		return m_funcBiGetCounter(nHandle, readno, readcounter);
	}
	return ERR_NO_PRINTER;
}

int		CStatusAPI::BiResetCounter(int nHandle, WORD writeno)
{
	if ( m_funcBiResetCounter != NULL  )
	{
		return m_funcBiResetCounter(nHandle, writeno);
	}
	return ERR_NO_PRINTER;
}

int 	CStatusAPI::BiOpenDrawer(int nHandle, BYTE drawer, BYTE pulse)
{
	if ( m_funcBiOpenDrawer != NULL  )
	{
		return m_funcBiOpenDrawer(nHandle, drawer, pulse);
	}
	return ERR_NO_PRINTER;	
}

int		CStatusAPI::BiSCNClampPaper(int nHandle)
{
	if ( m_funcBiSCNClampPaper != NULL  )
	{
		return m_funcBiSCNClampPaper(nHandle);
	}
	return ERR_NO_PRINTER;	
}

int 	CStatusAPI::BiForceResetPrinter(int nHandle)
{
	if ( m_funcBiForceResetPrinter != NULL  )
	{
		return m_funcBiForceResetPrinter(nHandle);
	}
	return ERR_NO_PRINTER;	
}

int 	CStatusAPI::BiGetExtendStatus(int nHandle, LPWORD lpStatus)
{
	if ( m_funcBiGetExtendStatus != NULL  )
	{
		return m_funcBiGetExtendStatus(nHandle, lpStatus);
	}
	return ERR_NO_PRINTER;	
}

