#ifndef __DYNAMICLIBRARY_H__
#define __DYNAMICLIBRARY_H__

#ifdef _WIN32
	#include <windows.h>
#else
	#include <dlfcn.h>

	typedef void* HMODULE;
#ifdef	USE_DEEPBIND
	#define	dlMODE	(RTLD_LAZY|RTLD_DEEPBIND)
#else
	#define	dlMODE	(RTLD_LAZY)
#endif
	#define	LoadLibrary(strLibName)				dlopen(strLibName, dlMODE/*RTLD_NOW*/)
	#define GetProcAddress(hLibrary, strSymbol)	dlsym(hLibrary, strSymbol)
	#define FreeLibrary(hLibrary)				dlclose(hLibrary)
#endif	/* #ifdef _WIN32 */

class CDynamicLibrary
{
	public:
		CDynamicLibrary();
		virtual ~CDynamicLibrary();

		CDynamicLibrary(const char* strDynLibName);
		bool Load(const char* strDynLibName);
		bool UnLoad();
		void* GetSymbol(const char* strSymbolName);
		bool IsLoaded();
	protected:
		HMODULE m_hDynLib;
	private:
};

#endif // __DYNAMICLIBRARY_H__
