#include "DynamicLibrary.h"

#include <stdlib.h>

CDynamicLibrary::CDynamicLibrary()
{
	m_hDynLib = NULL;
}

CDynamicLibrary::~CDynamicLibrary()
{
	UnLoad();
}

CDynamicLibrary::CDynamicLibrary(const char* strDynLibName)
{
	Load(strDynLibName);
}

bool CDynamicLibrary::Load(const char* strDynLibName)
{
	if(strDynLibName != NULL)
	{
		/* Unload if there's a dynamic library loaded */
		if(m_hDynLib != NULL)
		{
			UnLoad();
		}
		m_hDynLib = LoadLibrary(strDynLibName);
	}
	return IsLoaded();
}

bool CDynamicLibrary::UnLoad()
{
	bool bIsUnLoaded;
	bIsUnLoaded = false;
	if(m_hDynLib != NULL)
	{
		FreeLibrary(m_hDynLib);
		m_hDynLib = NULL;
		bIsUnLoaded = true;
	}
	return bIsUnLoaded;
}

void* CDynamicLibrary::GetSymbol(const char* strSymbolName)
{
	return GetProcAddress(m_hDynLib, strSymbolName);
}

bool CDynamicLibrary::IsLoaded()
{
	return (m_hDynLib != NULL);
}
