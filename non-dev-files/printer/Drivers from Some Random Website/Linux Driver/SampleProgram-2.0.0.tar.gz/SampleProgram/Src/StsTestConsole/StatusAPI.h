#ifndef __STATUSAPI_H__
#define __STATUSAPI_H__

#include "DynamicLibrary.h"

#ifndef APIENTRY
	#ifdef _WIN32
		#define APIENTRY	__stdcall
	#else
		#define APIENTRY
		#define CALLBACK
	#endif
#endif	/* #ifndef APIENTRY */

#ifdef _WIN32
	#define STATUSAPI_NAME	"EpsStmApi.dll"
#else
	#define STATUSAPI_NAME	"libEpsStmApi.so"
#endif	/* #ifdef _WIN32 */

#define		ERR_NO_PRINTER				-30				// There is not printer driver

typedef unsigned short	WORD;
typedef unsigned int	DWORD;
typedef DWORD*			LPDWORD;
typedef WORD*			LPWORD;
typedef unsigned char	BYTE;
typedef BYTE*			LPBYTE;
typedef int				BOOL;
typedef int				INT;
typedef char*			LPSTR;
typedef void*			LPVOID;

typedef int (CALLBACK *StatusCB_t)(DWORD, LPVOID);
typedef int (APIENTRY* BiOpenMonPrinter_t)(INT, LPSTR);
typedef int (APIENTRY* BiCloseMonPrinter_t)(INT);
typedef int (APIENTRY* BiLockPrinter_t)(INT, DWORD);
typedef int (APIENTRY* BiUnlockPrinter_t)(INT);
typedef int (APIENTRY* BiDirectIOEx_t)(INT, DWORD, LPBYTE, LPDWORD, LPBYTE, DWORD, BOOL, BYTE);
typedef int (APIENTRY* BiResetPrinter_t)(INT);
typedef int (APIENTRY* BiGetStatus_t)(INT, LPDWORD);
typedef int (APIENTRY* BiSetStatusBackFunctionEx2_t)(INT, StatusCB_t, LPVOID);
typedef int (APIENTRY* BiCancelStatusBack_t)(INT);
typedef int (APIENTRY* BiGetCounter_t)(INT, WORD, LPDWORD);
typedef int (APIENTRY* BiResetCounter_t)(INT, WORD);
typedef int (APIENTRY* BiOpenDrawer_t)(INT, BYTE, BYTE);
typedef int (APIENTRY* BiSCNClampPaper_t)(INT);
typedef int (APIENTRY* BiForceResetPrinter_t)(INT);
typedef int (APIENTRY* BiGetExtendStatus_t)(INT, LPWORD);

class CStatusAPI
{
public:
	CStatusAPI(bool bLoadLibrary = false);
	virtual ~CStatusAPI(void);
	bool Load();
	bool UnLoad();
	bool IsLoaded();
	int BiOpenMonPrinter(INT nPortType, LPSTR strName);
	int BiCloseMonPrinter(INT nHandle);
	int	BiLockPrinter(int nHandle, DWORD timeout);
	int	BiUnlockPrinter(int nHandle);
	int BiDirectIOEx(int nHandle, DWORD writeLen, LPBYTE writeCmd, LPDWORD readLen, LPBYTE readBuff, DWORD timeout,BOOL nullTerminate, BYTE option);
	int BiResetPrinter(int nHandle);
	int BiGetStatus(int nHandle, LPDWORD lpStatus);
	int BiSetStatusBackFunctionEx2 (int nHandle, StatusCB_t fnStatusBack, LPVOID lpParam);
	int	BiCancelStatusBack(int nHandle);
	int BiGetCounter(int nHandle, WORD readno, LPDWORD readcounter);
	int BiResetCounter(int nHandle, WORD writeno);
	int BiOpenDrawer(int nHandle, BYTE drawer, BYTE pulse);
	int	BiSCNClampPaper(int nHandle);
	int BiForceResetPrinter(int nHandle);
	int BiGetExtendStatus(int nHandle, LPWORD lpStatus);

private:
	BiOpenMonPrinter_t				m_funcBiOpenMonPrinter;
	BiCloseMonPrinter_t				m_funcBiCloseMonPrinter;
	BiLockPrinter_t					m_funcBiLockPrinter;
	BiUnlockPrinter_t				m_funcBiUnlockPrinter;
	BiDirectIOEx_t					m_funcBiDirectIOEx;
	BiResetPrinter_t				m_funcBiResetPrinter;
	BiGetStatus_t					m_funcBiGetStatus;
	BiSetStatusBackFunctionEx2_t	m_funcBiSetStatusBackFunctionEx2;
	BiCancelStatusBack_t			m_funcBiCancelStatusBack;
	BiGetCounter_t					m_funcBiGetCounter;
	BiResetCounter_t				m_funcBiResetCounter;
	BiOpenDrawer_t					m_funcBiOpenDrawer;
	BiSCNClampPaper_t				m_funcBiSCNClampPaper;
	BiForceResetPrinter_t			m_funcBiForceResetPrinter;
	BiGetExtendStatus_t				m_funcBiGetExtendStatus;

	CDynamicLibrary m_oDynLib;
};

#endif	/* #ifndef __STATUSAPI_H__ */
