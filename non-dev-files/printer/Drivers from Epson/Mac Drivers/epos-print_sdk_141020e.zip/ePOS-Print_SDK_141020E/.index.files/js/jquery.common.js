// pageTop Function
var hidePageTop = function(){
	var target = $('#pageTop').hide();
	var run = function() {
		if ($(window).scrollTop() >= 150) {
			if(jQuery.support.opacity){
				target.fadeIn();
			} else {
				target.show();
			}
		} else {
			if(jQuery.support.opacity){
				target.fadeOut();
			} else {
				target.hide();
			}
		}
	}
	run();
	$(window).scroll(function () {
		run();
	});
}


// help Function
var showHelp = function() {
	var target = $('.notes li');
	target.each(function() {
		$(this).append('<span class="icon"></span>');
		$(this).find('.help').prepend('<span></span>');
		$(this).hover(function(){
			var icon = $(this).find('.icon');
			var help = $(this).find('.help');
			var posX = icon.offset().left;
			var posY = icon.offset().top;
			var targetH = help.outerHeight();
			help.css({'top': posY - targetH + 'px', 'left': posX - 106 + 'px'});
			if(jQuery.support.opacity){
				help.stop().fadeIn();
			} else {
				help.show();
			}
		},function(){
			var help = $(this).find('.help');
			help.stop().hide();
		});
	});

}


$(function(){
	if( $('#pageTop').size() ) hidePageTop();
	if( $('.notes').size() ) showHelp();
});